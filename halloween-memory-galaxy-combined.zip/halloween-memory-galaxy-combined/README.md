# Halloween Memories & Memory Galaxy

Inspired by our school Halloween celebration: a two-chapter website with Pumpkin, Masquerade and a separate Memory Galaxy.

This is a complete standalone React/Three.js + Express/SQLite application. It shares maintained source with the other editions but requires no sibling folder to install or run. The root landing links to /halloween and /galaxy. Uploaded photographs are not included.

## Start locally

Requires **Node.js 24** and npm. In this package directory:

```sh
npm ci
npm run setup:admin
npm run dev
```

Choose your own username and a unique password/passphrase (16–256 characters, at least 8 distinct characters). The password and its confirmation are hidden and never printed or accepted as command arguments. There is no default account, public registration route or shared password.

Open **http://127.0.0.1:5173/**; sign in at **http://127.0.0.1:5173/admin** using your chosen credentials. The API uses port **3001**. Viewing works before setup; administrator login is disabled until setup is complete. Fresh storage is empty and private. Development submissions are enabled by default for local testing and remain pending until approval.

Optional: copy the blank .env.example to an ignored .env. Blank values retain defaults. Do not put passwords in it; ADMIN_PASSWORD is no longer supported. DATA_DIR applies to both setup and server commands. **Run setup and the server with the same private DATA_DIR and OS user.**

## Owner changes, recovery and existing data

```sh
npm run setup:admin -- --reset
```

Reset is a local operator action requiring filesystem access. It replaces the chosen username/password and invalidates all existing sessions, including on a running server. There is no email reset, MFA, password-recovery API or multi-admin feature. Protect access to the server and its private storage.

For an older installation with data/development-credentials.json, keep the existing data directory and run:

```sh
npm run setup:admin -- --migrate-legacy
```

This preserves the old login, writes a salted scrypt hash to private admin.json, then removes that plaintext file and revokes sessions. It refuses to replace an already-configured owner. No password is printed. If you used the old production ADMIN_PASSWORD environment setting instead, use --reset to choose credentials locally, remove that old environment secret and restart. Do not rely on ADMIN_PASSWORD after upgrading. The maintained combined workspace has already undergone legacy-file migration; its existing password was not changed. That private account/data is not present in this release.

Keep your private storage directory when replacing code. Never overwrite it with an empty release folder. Schema changes are additive; no auto-seeding, copying between editions or automatic imports occur.

## Side-by-side defaults

| Edition | Browser dev port | API / production port | Default private storage | Session cookie |
| --- | --- | --- | --- | --- |
| Combined | 5173 | 3001 | data/ | gallery_combined |
| Halloween | 5174 | 3002 | data-halloween/ | gallery_halloween |
| Galaxy | 5175 | 3003 | data-galaxy/ | gallery_galaxy |

Paths are relative to each package's working directory. Do not point different editions at the same directory. Production deployments should use separate HTTPS hostnames and private volumes; cookies are not port-scoped. Cookie names and exact development-origin checks reduce cross-edition contamination, but services sharing one origin are not a strong security boundary.

## Interaction

Drag to orbit; wheel/pinch to zoom; right-drag/two fingers to pan; Reset returns to the fitted view. Select a brighter memory dot to open its actual photograph. Escape closes; arrows browse. Keyboard users can reach Reveal memory controls or the collection grid. The existing reduced-motion support and 2D WebGL fallback remain. Galaxy offers whole-universe and closer perspectives, real caption/upload-time details and gentle coherent rotation.

## Uploads, moderation and privacy

- /submit accepts JPEG/PNG/WebP: up to 10 images, 10 MB each, **25 MB total**, 40 megapixels and 16,000 pixels per dimension. Server-side signatures, decoding, pixel/page bounds, concurrency and rate limits apply. Full images are resized inside 2000×2000; thumbnails are 480×360. Re-encoding strips EXIF/GPS, XMP/IPTC and original filenames.
- One optional caption (max 280 characters) applies to every image in that submission. It is reviewed alongside the photos. No relationships, names or captions are invented. Existing empty captions remain empty. Public upload time is the collection timestamp, not when the image was taken.
- Pending, hidden and rejected images require an administrator session even with a known direct URL. Only approved entries appear in the public collection. **Approved photographs, captions, upload timestamps and configured branding are public to anyone with access to the website/direct URL.** Hiding/deleting cannot retract copies already downloaded by visitors.
- Contributors must have rights and any required guardian/subject consent for unrestricted public display. An administrator's approval does not itself establish consent or image/likeness/mark rights. Remove sensitive text and faces if the actual audience is not authorized. Photo consent is not a software redistribution license.
- /admin reviews pending photos and can approve, reject, hide or permanently delete them. Deletion requires confirmation. Branding/logo changes are administrator-only. React renders captions/branding as plain text. Source filenames, account details and raw EXIF are not in public API output.
- Both fonts are self-hosted; no Google Fonts requests, analytics or remote photo storage are configured.

## Build, tests and production

```sh
npm run build
npm test
npm start
```

npm start serves dist/ and the API at http://127.0.0.1:3001 by default. Use npm run dev for the Vite URL above. A static-only host (including GitHub Pages) cannot run uploads/moderation. Publishing source to GitHub does not deploy the backend.

For production, configure your private .env with NODE_ENV=production, your exact HTTPS PUBLIC_ORIGIN (scheme + host + optional port, no trailing slash), a persistent private DATA_DIR outside public/dist, and optionally ALLOW_PUBLIC_UPLOADS=true. **Production public submissions default OFF.** Enable them deliberately only after audience/consent checks. The form reports when submissions are closed.

Run setup on that same volume before starting the service. Use an HTTPS reverse proxy, retain the loopback HOST default, and block direct external access to the API port. Secure, HttpOnly, SameSite=Strict cookies require HTTPS in production. Set TRUST_PROXY only to the actual proxy IP/CIDR list if needed for scheme/IP handling; do not trust arbitrary forwarded headers. Configure proxy request-body limit at 26 MiB (to allow multipart overhead above the 25 MiB image cap), upload timeouts, connection limits and storage monitoring. Rate limits are in-memory and single-instance. Do not log request bodies, passwords, cookies, photos or tokens.

Back up the **entire private directory** (SQLite, image objects and hash-only admin.json) with the server stopped, or use a consistent SQLite backup plus a coordinated objects backup. Encrypt/protect backups and validate restore. Defaults use 0700 directories / 0600 sensitive files on POSIX; review equivalent ACLs on Windows. Never commit private storage, backups, screenshots, .env, logs or filled-in configuration. No actual media or account is included here.

## Licensing and before publication

Original code: **PolyForm Noncommercial 1.0.0** (LICENSE), with attribution via the Required Notice lines in NOTICE. Fill in the public author/rights-holder and repository placeholders before publication; npm run build copies the current notices to public/ for website distribution. This is source-available, not unrestricted open source. Its permitted purposes include specific educational/charitable uses; ambiguous commercial arrangements require legal review.

Software rights do not cover photos, captions, likenesses, reference imagery or logos. Third-party assets retain their own licenses. The downloaded pumpkin is CC0; fonts are SIL OFL; library notices are in THIRD_PARTY.md, DEPENDENCY_LICENSES.md and DEPENDENCY_NOTICES.txt. Some shared source/model files remain in each edition for reproducible tests and maintenance, but disabled experiences have no routes or UI.

Read **SECURITY_PRIVACY_REVIEW.md** and **RELEASE_SUMMARY.md**. No Git repository/history exists in the supplied workspace, so earlier commits could not be audited. If you have an upstream repository, audit its complete history and rotate any exposed credentials before pushing. Do not assume tests establish complete security or legal clearance.

## Re-export all editions

The source is maintained in one app. npm run release creates three allowlisted source packages and ZIPs in releases/ (or pass --output /absolute/directory). No private data, credentials, screenshots, dependencies or build caches are copied. Each output has its own app.config.json and package name. Run npm ci, npm run build and npm test inside each output independently. Existing export folders are never overwritten automatically.
