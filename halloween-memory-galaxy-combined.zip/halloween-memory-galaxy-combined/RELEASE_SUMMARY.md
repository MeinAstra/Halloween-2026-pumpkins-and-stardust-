# Three independent releases — November 1, 2026

The existing combined website is the shared source of truth. No scene geometry, shaders, camera behavior or layout was intentionally redesigned. Standalone changes are destination navigation, general-purpose wording in Galaxy and separate storage/port/session defaults. Fonts retain the same families but are served locally. Security-related copy now makes public display explicit.

| Package | Root experience | Dev / API ports | Private storage default |
| --- | --- | --- | --- |
| halloween-memory-galaxy-combined | Existing two-experience landing | 5173 / 3001 | data/ |
| halloween-memories-standalone | Pumpkin + Masquerade | 5174 / 3002 | data-halloween/ |
| memory-galaxy-standalone | Memory Galaxy | 5175 / 3003 | data-galaxy/ |

Each folder and matching ZIP is self-contained, with source, lockfile, blank configuration template, tests, local CLI setup, licensed model/fonts and notices. All fresh releases start without photos, administrator credentials or a populated storage directory. Storage is created privately on first setup/start. There are no sibling-path runtime dependencies. Build output and dependencies are deliberately omitted: run npm ci and npm run build in each package.

## Administrator setup — same commands in each package

```sh
npm ci
npm run setup:admin
npm run dev
```

Choose your own username and password privately in your local terminal. There is no shared default. Use that package's /admin URL. Reset/change locally with `npm run setup:admin -- --reset`. Production requires an exact HTTPS PUBLIC_ORIGIN, persistent private storage and HTTPS proxy; public uploads default off until explicitly enabled. See each README.

The original combined workspace's legacy development account was migrated to hash-only storage while preserving its existing username/password. Existing sessions were revoked deliberately. The initial nine records / 18 images passed preservation checks. The owner later confirmed deleting four duplicates while working in the live site. Those intentional deletions were kept: the final five remaining records and ten image files match the original fields and hashes, with branding unchanged. No restoration was performed. No private data was copied to standalone releases.

## Changed implementation

- `app.config.json`, `server/config.mjs`, `src/release.ts`: per-edition routes, defaults, navigation and copy.
- `src/main.tsx`, `Header.tsx`, `Gallery.tsx`, `PhotoViewer.tsx`, `Workflow.tsx`, `types.ts`, `style.css`: preserve existing UI with correct standalone boundaries, custom username login, accurate audience consent, upload availability/limits, local fonts and corrected photo-dialog focus restoration.
- `server/admin.mjs`, `server/setup-admin.mjs`, `server/index.mjs`: hash-only owner bootstrap, legacy migration, credential resets and helpful startup behavior.
- `server/app.mjs`: session revision checks/cookie isolation, production-origin/upload controls, bounded uploads, signature/dimension checks and safe static routes/storage.
- `package.json`, lockfile, Vite/TypeScript config: patched Sharp, local fonts, setup/build/release commands.
- `tests/security.test.mjs`, `tests/release.test.mjs`, test helpers and existing API/metadata tests: setup/privacy/isolation regressions; generated temporary credentials only.
- `scripts/`: reproducible allowlisted exports, archive scanning, README generation, license synchronization and dependency notice inventory.
- `LICENSE`, `NOTICE`, `THIRD_PARTY.md`, README, dependency notices and `SECURITY_PRIVACY_REVIEW.md`: release rights, setup, audit evidence and pre-publication checks.

## Verification and limits

All three independently installed releases pass their production builds and all 33 tests (99 release test passes total). Desktop/mobile scene screenshots and keyboard memory viewing were checked; a focus-return regression was fixed. After the owner-confirmed duplicate cleanup, the final five records and ten image files match the original fields/hashes. Final audit reports zero known dependency advisories. Full evidence and limits are in SECURITY_PRIVACY_REVIEW.md. Production builds may retain Vite's warning for the large lazy Three.js chunk. A passing suite or zero-advisory npm audit is not a complete security certification.

Before publication, fill in NOTICE's author/repository placeholders, independently verify consent for the actual public audience, inspect any upstream Git history (none exists in this supplied working tree), review deployment proxy/volume/backup settings and rerun dependency/security checks. The single-photo-derived mask may require rights review. No push, public deployment, history rewrite or automatic real-media import was performed.
