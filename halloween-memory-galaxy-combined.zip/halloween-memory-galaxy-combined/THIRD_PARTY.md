# Third-party sources

## Pumpkin model

- Model: Pumpkin, Grab3D / Cozy Fruit & Vegetables Kit
- Source: https://grab3d.com/models/food/pumpkin/
- Download: https://grab3d.com/dl/pumpkin/pumpkin.glb
- License: CC0 1.0 Universal, public domain dedication
- License text supplied with the asset: `public/models/LICENSE-pumpkin.txt`
- Upstream geometry: 7,488 triangles; no carved face
- Local modifications: bounding-box normalization, matte orange and green vertex colors, friendly decorative facial details, and separately raycast dotted contours

The source's license notice describes procedural Blender generation with AI-assisted generator scripts. The GLB is an authored downloaded asset; it is not the previous application's sphere-based pumpkin.

## Architectural reference

https://github.com/yftan/christmas-tree by yftan identifies its project as MIT-licensed in its README. Its React Three Fiber separation of scene, shape data, particles, frame-based interpolation and photo viewing informed the initial architecture. The Halloween geometry, particle interaction, backend and UI code here were written for this application; no reference source text was copied verbatim. Git cloning failed during reference inspection; its README and TreeSystem source were inspected through the public web interface.

## Runtime libraries

React, Three.js, React Three Fiber, Drei, Vite, Lucide, Express, Helmet, Multer, Sharp and express-rate-limit retain their respective upstream license files in installed dependencies. See package-lock.json for exact installed versions.

## Celestial refinement references

The following user-supplied sources were inspected for the principles of GPU particle motion, layered cloud morphology, per-particle attributes and soft circular point sprites. The new shaders and distributions were written specifically for this app; no source implementation was copied.

- https://vibecruiser.com/v/nipale-ai--galaxy and its linked source https://github.com/Nipale-ai/galaxy
- https://github.com/wagiham/threejs-cosmic-modes (including its script.js shader code)
- https://tympanus.net/codrops/2022/06/21/creating-a-particles-galaxy-with-three-js/

The porcelain half-mask is a custom mesh informed by the user-supplied single photograph. It is an artistic reconstruction with inferred depth; the reference image is not embedded or redistributed in the website.

## Current release licensing and privacy review (2026-11-01)

The original software uses PolyForm Noncommercial 1.0.0, with Required Notice lines in NOTICE and the unmodified official license text in LICENSE. Third-party works are not relicensed under those terms. Public author/repository placeholders still require the owner's completion before distribution.

The actual Grab3D pumpkin page was rechecked and identifies the download as CC0: https://grab3d.com/models/food/pumpkin/ . Its supplied notice remains in public/models/LICENSE-pumpkin.txt. No Sketchfab model is included.

DM Sans and Playfair Display are now served locally from Fontsource's packages, preserving the existing typefaces without requests to Google Fonts. Their SIL Open Font License texts are in public/fonts/*-OFL.txt. These notices identify the respective original font copyright holders. The local Latin font subsets fall back to system fonts for unsupported scripts.

DEPENDENCY_LICENSES.md records installed library versions and declared licenses. DEPENDENCY_NOTICES.txt includes the installed verbatim license/notice files, including MIT/ISC/BSD/Apache notices and Sharp/libvips-related notices. Optional native binary packages differ by platform; retain the actual npm-installed notices when redistributing binaries. No native dependency binaries or node_modules are shipped in the source ZIPs. Review LGPL obligations if separately distributing native binaries or a packaged/container runtime.

Reference photographs, uploaded school/student photographs, screenshots containing people, school/community logos and private records are not part of the code releases. The mask is an artistic custom geometry informed by a photograph, not a licensed copy of that photograph; whether its resemblance raises rights concerns has not been legally determined. Obtain any necessary rights clearance before public use. The software license provides no likeness, trademark or photo-content rights.

Primary license source: https://raw.githubusercontent.com/polyformproject/polyform-licenses/1.0.0/PolyForm-Noncommercial-1.0.0.md

Prior-source architectural/provenance notes above were carried forward from the existing project documentation. With no Git history available, full authorship provenance could not be independently reconstructed. Before public distribution, the owner must confirm rights to the original application and any reference-derived work.
