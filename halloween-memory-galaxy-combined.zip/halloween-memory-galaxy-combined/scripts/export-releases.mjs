import {cpSync,mkdirSync,existsSync,readFileSync,writeFileSync} from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {variants} from '../server/config.mjs';
import {readme} from './readme.mjs';
const index=process.argv.indexOf('--output'),destination=path.resolve(index<0?'releases':process.argv[index+1]);
const dirs=['src','server','tests','scripts','public'];
const files=['app.config.json','package.json','package-lock.json','tsconfig.json','vite.config.ts','index.html','.gitignore','.env.example','README.md','LICENSE','NOTICE','THIRD_PARTY.md','DEPENDENCY_LICENSES.md','DEPENDENCY_NOTICES.txt','SECURITY_PRIVACY_REVIEW.md','RELEASE_SUMMARY.md'];
for(const c of Object.values(variants))if(existsSync(path.join(destination,c.name))||existsSync(path.join(destination,c.name+'.zip')))throw new Error('Export destination already exists. Choose a new empty output location.');
mkdirSync(destination,{recursive:true});
for(const c of Object.values(variants)){
 const output=path.join(destination,c.name);mkdirSync(output);
 for(const file of [...dirs,...files]){if(!existsSync(file))throw new Error(`Required release file missing: ${file}`);cpSync(file,path.join(output,file),{recursive:true,filter:src=>!src.split(path.sep).includes('.DS_Store')});}
 writeFileSync(path.join(output,'app.config.json'),JSON.stringify(c,null,2)+'\n');
 const pkg=JSON.parse(readFileSync('package.json','utf8'));pkg.name=c.name;writeFileSync(path.join(output,'package.json'),JSON.stringify(pkg,null,2)+'\n');
 const lock=JSON.parse(readFileSync('package-lock.json','utf8'));lock.name=c.name;lock.packages[''].name=c.name;lock.packages[''].license=pkg.license;writeFileSync(path.join(output,'package-lock.json'),JSON.stringify(lock,null,2)+'\n');
 writeFileSync(path.join(output,'README.md'),readme(c));
 let html=readFileSync('index.html','utf8').replace(/<title>.*?<\/title>/,`<title>${c.title.replaceAll('&','&amp;')}</title>`).replace(/name="description" content="[^"]*"/,`name="description" content="${c.variant==='galaxy'?'A three-dimensional universe for your personal, community and event memories.':c.variant==='halloween'?'Remember a Halloween celebration through Pumpkin and Masquerade memory sculptures.':'Explore Halloween memory sculptures and a separate galaxy of real memories.'}"`);writeFileSync(path.join(output,'index.html'),html);
 const result=spawnSync('python3',[path.resolve('scripts/verify-archive.py'),'--create',output],{stdio:'inherit'});if(result.status!==0)throw new Error('Release archive verification failed');
 console.log(`Exported ${c.name}`);
}
