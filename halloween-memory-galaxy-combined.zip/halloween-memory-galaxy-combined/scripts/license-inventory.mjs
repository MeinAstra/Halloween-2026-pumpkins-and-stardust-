import {readFileSync,writeFileSync,readdirSync,existsSync} from 'node:fs';
import path from 'node:path';
const lock=JSON.parse(readFileSync('package-lock.json','utf8')),rows=[];
let notices='# Installed dependency license notices\n\nGenerated from the exact installed lockfile. These licenses remain independent of the application license.\n\n';
for(const [key,info]of Object.entries(lock.packages).sort()){
 if(!key||!existsSync(path.join(key,'package.json')))continue;
 const pkg=JSON.parse(readFileSync(path.join(key,'package.json'),'utf8'));rows.push(`| ${pkg.name} | ${pkg.version} | ${pkg.license||'SEE UPSTREAM'} |`);
 const licenseFiles=readdirSync(key).filter(n=>/^(licen[cs]e|copying|notice)(\.|$)/i.test(n));
 for(const file of licenseFiles){const full=path.join(key,file);try{notices+=`\n## ${pkg.name}@${pkg.version} — ${file}\n\n`+readFileSync(full,'utf8')+'\n';}catch{}}
}
writeFileSync('DEPENDENCY_LICENSES.md','# Dependency license inventory\n\n| Package | Version | Declared license |\n| --- | --- | --- |\n'+rows.join('\n')+'\n\nSee DEPENDENCY_NOTICES.txt for verbatim installed notices. Optional binaries vary by platform; npm ci installs the matching platform packages and their license files.\n');writeFileSync('DEPENDENCY_NOTICES.txt',notices);
