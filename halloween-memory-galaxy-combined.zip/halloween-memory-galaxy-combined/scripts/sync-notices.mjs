import {copyFileSync,mkdirSync} from 'node:fs';
mkdirSync('public',{recursive:true});for(const name of ['LICENSE','NOTICE'])copyFileSync(name,`public/${name}.txt`);
