"""Allowlist archive creation and check contents without printing credentials or media."""
import sys,zipfile,hashlib,re,json
from pathlib import Path
allowed_dirs={'src','server','tests','scripts','public'}
allowed_files={'app.config.json','package.json','package-lock.json','tsconfig.json','vite.config.ts','index.html','.gitignore','.env.example','README.md','LICENSE','NOTICE','THIRD_PARTY.md','DEPENDENCY_LICENSES.md','DEPENDENCY_NOTICES.txt','SECURITY_PRIVACY_REVIEW.md','RELEASE_SUMMARY.md'}
allowed_media={'public/models/pumpkin.glb','public/fonts/dm-sans-latin-standard-normal.woff2','public/fonts/playfair-display-latin-wght-normal.woff2','public/fonts/playfair-display-latin-wght-italic.woff2'}
secret=re.compile(rb'gh[pousr]_[A-Za-z0-9]{30,}|sk-proj-[A-Za-z0-9_-]{30,}|AKIA[0-9A-Z]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')
def verify(z):
 assert z.testzip() is None
 names=z.namelist();roots={n.split('/')[0] for n in names};assert len(roots)==1
 for n in names:
  p=Path(n);relative='/'.join(p.parts[1:]);assert not p.is_absolute() and '..' not in p.parts
  assert relative in allowed_files or p.parts[1] in allowed_dirs,n
  assert not any(x in {'node_modules','data','data-halloween','data-galaxy','screenshots','.git','dist','__pycache__'} for x in p.parts),n
  assert p.name not in {'admin.json','development-credentials.json','.env','.DS_Store'},n
  assert not re.search(r'\.(sqlite.*|db|log|bak|zip|png|jpe?g|webp|gif)$',n,re.I),n
  if p.suffix in {'.glb','.woff2'}:assert relative in allowed_media,n
  payload=z.read(n);assert not secret.search(payload),'Potential secret detected; value withheld'
 for f in ['README.md','.env.example','LICENSE','NOTICE','package-lock.json','server/setup-admin.mjs']:assert next(iter(roots))+'/'+f in names
 return len(names)
if sys.argv[1]=='--create':
 root=Path(sys.argv[2]);target=root.with_suffix('.zip')
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(root.rglob('*')):
   if p.is_file() and ('/'.join(p.relative_to(root).parts) in allowed_files or p.relative_to(root).parts[0] in allowed_dirs):
    if '__pycache__' in p.parts or p.name=='.DS_Store':continue
    info=zipfile.ZipInfo(root.name+'/'+str(p.relative_to(root)),date_time=(2026,11,1,0,0,0));info.external_attr=0o100644<<16;z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED)
else:target=Path(sys.argv[1])
with zipfile.ZipFile(target) as z:count=verify(z)
print(json.dumps({'archive':target.name,'files':count,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'crc':'pass','private_files':'excluded'}))
