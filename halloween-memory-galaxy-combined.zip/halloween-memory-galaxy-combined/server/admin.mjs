import {randomBytes,scrypt as derive,timingSafeEqual,createHash} from 'node:crypto';
import {promisify} from 'node:util';
import {mkdirSync,existsSync,readFileSync,writeFileSync,renameSync,chmodSync,realpathSync,readdirSync} from 'node:fs';
import path from 'node:path';
const scrypt=promisify(derive),options={N:32768,r:8,p:1,maxmem:64*1024*1024};

export function ensurePrivateDir(dataDir){
 const resolved=path.resolve(dataDir);
 if(resolved===path.parse(resolved).root||resolved===process.cwd()||['public','dist'].some(d=>resolved===path.resolve(d)||resolved.startsWith(path.resolve(d)+path.sep)))throw new Error('DATA_DIR must be outside public directories');
 if(existsSync(dataDir)&&readdirSync(dataDir).length&&!['admin.json','development-credentials.json','gallery.sqlite'].some(f=>existsSync(path.join(dataDir,f))))throw new Error('Choose an empty private application directory, not an unrelated existing folder.');
 mkdirSync(dataDir,{recursive:true,mode:0o700});
 const real=realpathSync(dataDir);
 if(['public','dist'].some(d=>existsSync(d)&&(real===realpathSync(d)||real.startsWith(realpathSync(d)+path.sep))))throw new Error('DATA_DIR resolves into a public directory');
 chmodSync(dataDir,0o700);
}
export const adminPath=dataDir=>path.resolve(dataDir,'admin.json');
export function validateAdmin(username,password){
 if(typeof username!=='string'||! /^[A-Za-z0-9._-]{3,64}$/.test(username))throw new Error('Username must be 3–64 letters, digits, dots, underscores or hyphens.');
 if(typeof password!=='string'||password.length<16||password.length>256||!password.trim()||new Set(password).size<8)throw new Error('Use 16–256 characters with at least 8 distinct characters; a long unique passphrase is recommended.');
}
export async function saveAdmin(dataDir,username,password,{replace=false}={}){
 validateAdmin(username,password);ensurePrivateDir(dataDir);
 const file=adminPath(dataDir);if(existsSync(file)&&!replace)throw new Error('Administrator already exists. Use --reset to replace it locally.');
 const salt=randomBytes(16).toString('hex'),hash=(await scrypt(password,salt,64,options)).toString('hex');
 const record={version:1,username,salt,hash,revision:randomBytes(16).toString('hex')};
 const temp=`${file}.${randomBytes(8).toString('hex')}.tmp`;writeFileSync(temp,JSON.stringify(record,null,2)+'\n',{mode:0o600,flag:'wx'});renameSync(temp,file);chmodSync(file,0o600);return record;
}
export function loadAdmin(dataDir){
 const file=adminPath(dataDir);if(!existsSync(file))return null;
 const c=JSON.parse(readFileSync(file,'utf8'));
 if(c.version!==1||! /^[A-Za-z0-9._-]{3,64}$/.test(c.username)||! /^[a-f0-9]{32}$/.test(c.salt)||! /^[a-f0-9]{128}$/.test(c.hash)||! /^[a-f0-9]{32}$/.test(c.revision))throw new Error('Invalid private administrator configuration. Run npm run setup:admin -- --reset locally.');
 return c;
}
export async function verifyAdmin(record,username,password){
 // Perform the same derivation even for an unknown username.
 const input=typeof password==='string'&&password.length<=256?password:'';
 const candidate=await scrypt(input,record.salt,64,options);
 const valid=timingSafeEqual(Buffer.from(record.hash,'hex'),candidate);
 return valid&&username===record.username;
}
export const adminRevision=record=>record?createHash('sha256').update(record.revision).digest('hex'):'';
