import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import multer from 'multer';
import sharp from 'sharp';
import { DatabaseSync } from 'node:sqlite';
import { randomBytes, createHash } from 'node:crypto';
import { mkdirSync, existsSync, writeFileSync, rmSync, chmodSync, realpathSync } from 'node:fs';
import path from 'node:path';
import {release,allowedPage} from './config.mjs';
import {loadAdmin,verifyAdmin,adminRevision,ensurePrivateDir} from './admin.mjs';


export function createApp({dataDir=process.env.DATA_DIR || release.dataDir, production=process.env.NODE_ENV==='production', publicOrigin=process.env.PUBLIC_ORIGIN, variant=release.variant, allowPublicUploads=process.env.ALLOW_PUBLIC_UPLOADS==='true'||(!production&&process.env.ALLOW_PUBLIC_UPLOADS!=='false')}={}) {
  if(!['combined','halloween','galaxy'].includes(variant))throw new Error('Invalid application variant');
  if(production&&(!publicOrigin||new URL(publicOrigin).origin!==publicOrigin||!publicOrigin.startsWith('https://')))throw new Error('Production requires an exact HTTPS PUBLIC_ORIGIN');
  const cookieName=`gallery_${variant}`;
  ensurePrivateDir(dataDir);
  const objects=path.resolve(dataDir,'objects'); mkdirSync(objects,{recursive:true,mode:0o700});
  if(!realpathSync(objects).startsWith(realpathSync(dataDir)+path.sep))throw new Error('Image storage must remain within DATA_DIR');
  const db=new DatabaseSync(path.resolve(dataDir,'gallery.sqlite'));
  db.exec(`PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS photos(id TEXT PRIMARY KEY,status TEXT NOT NULL,created INTEGER NOT NULL,demo INTEGER DEFAULT 0); CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,expires INTEGER); CREATE TABLE IF NOT EXISTS config(key TEXT PRIMARY KEY,value TEXT);`);
  if(!db.prepare('PRAGMA table_info(photos)').all().some(column=>column.name==='caption'))db.exec("ALTER TABLE photos ADD COLUMN caption TEXT NOT NULL DEFAULT ''");
  if(!db.prepare('PRAGMA table_info(sessions)').all().some(column=>column.name==='revision'))db.exec("ALTER TABLE sessions ADD COLUMN revision TEXT NOT NULL DEFAULT ''");
  for(const file of ['gallery.sqlite','gallery.sqlite-wal','gallery.sqlite-shm']){const p=path.resolve(dataDir,file);if(existsSync(p))chmodSync(p,0o600);}
  chmodSync(objects,0o700);
  const app=express(); app.disable('x-powered-by');
  // Trust only explicitly configured proxy addresses, never arbitrary forwarded headers.
  if(process.env.TRUST_PROXY)app.set('trust proxy',process.env.TRUST_PROXY.split(',').map(p=>p.trim()));
  app.use(helmet({contentSecurityPolicy:production?{directives:{defaultSrc:["'self'"],fontSrc:["'self'"],scriptSrc:["'self'"],styleSrc:["'self'","'unsafe-inline'"],imgSrc:["'self'","blob:","data:"],connectSrc:["'self'"],workerSrc:["'self'","blob:"]}}:false}));
  app.use('/api',rateLimit({windowMs:60000,limit:150,standardHeaders:'draft-8',legacyHeaders:false}));
  app.use(express.json({limit:'128kb'}));
  const developmentPort=({combined:5173,halloween:5174,galaxy:5175})[variant];
  const developmentOrigins=new Set([`http://127.0.0.1:${developmentPort}`,`http://localhost:${developmentPort}`]);
  app.use('/api',(req,res,next)=>{
    res.set('Cache-Control','no-store');
    const origin=req.headers.origin;
    if(req.get('Sec-Fetch-Site')==='cross-site'&&!['GET','HEAD','OPTIONS'].includes(req.method))return res.status(403).json({error:'Cross-origin request denied'});
    const allowed=origin===(publicOrigin || `${req.protocol}://${req.get('host')}`) || (!production && developmentOrigins.has(origin));
    if(!['GET','HEAD','OPTIONS'].includes(req.method) && origin && !allowed) return res.status(403).json({error:'Cross-origin request denied'});
    next();
  });
  const hash=t=>createHash('sha256').update(t).digest('hex');
  const sessionToken=req=>req.headers.cookie?.split(';').map(s=>s.trim()).find(s=>s.startsWith(cookieName+'='))?.slice(cookieName.length+1);
  const admin=(req,res,next)=>{
    const token=sessionToken(req),credentials=loadAdmin(dataDir);
    if(!credentials||!token||!/^[A-Za-z0-9_-]{43}$/.test(token)||!db.prepare('SELECT token FROM sessions WHERE token=? AND expires>? AND revision=?').get(hash(token),Date.now(),adminRevision(credentials)))return res.status(401).json({error:'Administrator sign-in required'});
    next();
  };
  const config=()=>({school:variant==='galaxy'?'Our memories':variant==='halloween'?'Your celebration':'Your school',title:variant==='galaxy'?'Memory Galaxy':'Halloween Memories',accent:'#ef9b54',logo:'',...Object.fromEntries(db.prepare('SELECT * FROM config').all().map(r=>[r.key,r.value]))});
  const photo=r=>({id:r.id,status:r.status,demo:!!r.demo,caption:r.caption||'',uploadedAt:new Date(r.created).toISOString(),thumb:`/api/photos/${r.id}/thumb`,full:`/api/photos/${r.id}/full`});
  app.get('/api/gallery',(req,res)=>res.json({config:config(),uploadsEnabled:allowPublicUploads,photos:db.prepare("SELECT * FROM photos WHERE status='approved' ORDER BY created,id LIMIT 240").all().map(photo)}));
  app.get('/api/session',admin,(req,res)=>res.json({authenticated:true}));
  let verifying=0;
  app.post('/api/login',rateLimit({windowMs:900000,limit:8}),async(req,res)=>{
    const credentials=loadAdmin(dataDir);
    if(!credentials)return res.status(503).json({error:'Administrator setup is incomplete. The owner must run npm run setup:admin locally.'});
    if(verifying>=2)return res.status(429).json({error:'Please try again shortly'});
    verifying++;let valid=false;
    try{valid=await verifyAdmin(credentials,req.body?.username,req.body?.password);}finally{verifying--;}
    if(!valid||adminRevision(loadAdmin(dataDir))!==adminRevision(credentials))return res.status(401).json({error:'Incorrect credentials'});
    db.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now());
    const token=randomBytes(32).toString('base64url');db.prepare('INSERT INTO sessions(token,expires,revision) VALUES(?,?,?)').run(hash(token),Date.now()+8*3600000,adminRevision(credentials));
    res.cookie(cookieName,token,{httpOnly:true,sameSite:'strict',secure:production,maxAge:8*3600000,path:'/api'}).json({ok:true});
  });
  app.post('/api/logout',admin,(req,res)=>{db.prepare('DELETE FROM sessions WHERE token=?').run(hash(sessionToken(req)));res.clearCookie(cookieName,{path:'/api',httpOnly:true,sameSite:'strict',secure:production}).json({ok:true});});
  // Enforce a per-request aggregate bound while streams arrive, before buffering.
  const storage={_handleFile(req,file,cb){const chunks=[];file.stream.on('data',chunk=>{req.uploadBytes=(req.uploadBytes||0)+chunk.length;if(req.uploadBytes>25*1024*1024){chunks.length=0;file.stream.destroy(new multer.MulterError('LIMIT_FILE_SIZE'));}else chunks.push(chunk);});file.stream.on('error',cb);file.stream.on('end',()=>cb(null,{buffer:Buffer.concat(chunks),size:chunks.reduce((n,b)=>n+b.length,0)}));},_removeFile(req,file,cb){delete file.buffer;cb(null);}};
  let processingUploads=0;
  const uploadSlot=(req,res,next)=>{if(!allowPublicUploads)return res.status(403).json({error:'Public submissions are disabled by the owner.'});if(processingUploads>=2)return res.status(429).json({error:'Uploads are busy. Please try again shortly.'});processingUploads++;let released=false;req.releaseUpload=()=>{if(!released){released=true;processingUploads--;}};res.once('close',()=>{if(!req.processingMedia)req.releaseUpload();});next();};
  const upload=multer({storage,limits:{fileSize:10*1024*1024,files:10,fields:2,fieldSize:2048,parts:12},fileFilter:(req,file,cb)=>cb(null,['image/jpeg','image/png','image/webp'].includes(file.mimetype))});
  app.post('/api/submissions',rateLimit({windowMs:3600000,limit:20}),uploadSlot,upload.array('photos',10),async(req,res,next)=>{
    if(req.body.consent!=='true') return res.status(400).json({error:'Display permission is required'});
    const caption=req.body.caption??'';
    if(typeof caption!=='string'||caption.length>280)return res.status(400).json({error:'Caption must be 280 characters or fewer'});
    if(!req.files?.length) return res.status(400).json({error:'Choose 1–10 JPEG, PNG or WebP photos'});
    const saved=[];req.processingMedia=true;
    try {
      // Decode/re-encode every file before committing any records; EXIF and filenames are discarded.
      const encoded=[];
      for(const f of req.files){
        const signature=f.buffer.subarray(0,12);
        if(!(signature[0]===255&&signature[1]===216&&signature[2]===255)&&signature.subarray(0,8).toString('hex')!=='89504e470d0a1a0a'&&!(signature.subarray(0,4).toString()==='RIFF'&&signature.subarray(8,12).toString()==='WEBP'))throw new Error('Unsupported image');
        const meta=await sharp(f.buffer,{limitInputPixels:40000000}).metadata();
        if(!meta.width||!meta.height||meta.width>16000||meta.height>16000||!['jpeg','png','webp'].includes(meta.format) || (meta.pages||1)>1) throw new Error('Unsupported image');
        const image=sharp(f.buffer,{limitInputPixels:40000000}).rotate();
        encoded.push({id:randomBytes(16).toString('hex'),full:await image.clone().resize(2000,2000,{fit:'inside',withoutEnlargement:true}).webp({quality:88}).toBuffer(),thumb:await image.clone().resize(480,360,{fit:'cover'}).webp({quality:78}).toBuffer()});
      }
      for(const p of encoded){saved.push(p.id);writeFileSync(path.join(objects,`${p.id}-full.webp`),p.full,{mode:0o600});writeFileSync(path.join(objects,`${p.id}-thumb.webp`),p.thumb,{mode:0o600});}
      db.exec('BEGIN');try {for(const p of encoded)db.prepare('INSERT INTO photos(id,status,created,demo,caption) VALUES(?,?,?,0,?)').run(p.id,'pending',Date.now(),caption.trim());db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}
      res.status(201).json({count:encoded.length,status:'pending'});
    } catch(e){for(const id of saved)for(const v of ['full','thumb'])rmSync(path.join(objects,`${id}-${v}.webp`),{force:true});res.status(400).json({error:'Image could not be processed. Use a valid JPEG, PNG or WebP under 10 MB and 40 megapixels.'});}finally{req.releaseUpload();}
  });
  app.get('/api/photos/:id/:variant',(req,res,next)=>{
    if(!/^[a-f0-9]{32}$/.test(req.params.id) || !['thumb','full'].includes(req.params.variant)) return res.sendStatus(404);
    const p=db.prepare('SELECT * FROM photos WHERE id=?').get(req.params.id); if(!p)return res.sendStatus(404);
    const send=()=>{res.set('Cache-Control','private, no-store');res.sendFile(path.join(objects,`${p.id}-${req.params.variant}.webp`));};
    if(p.status==='approved')send();else admin(req,res,send);
  });
  app.get('/api/admin/photos',admin,(req,res)=>res.json(db.prepare('SELECT * FROM photos ORDER BY created DESC').all().map(photo)));
  app.patch('/api/admin/photos',admin,(req,res)=>{
    const {ids,status}=req.body;
    if(!Array.isArray(ids)||!ids.length||ids.length>240||!ids.every(id=>typeof id==='string'&&/^[a-f0-9]{32}$/.test(id))||!['approved','rejected','hidden','deleted'].includes(status))return res.status(400).json({error:'Invalid moderation request'});
    for(const id of ids){if(status==='deleted'){db.prepare('DELETE FROM photos WHERE id=?').run(id);for(const v of ['full','thumb'])rmSync(path.join(objects,`${id}-${v}.webp`),{force:true});}else db.prepare('UPDATE photos SET status=? WHERE id=?').run(status,id);}
    res.json({ok:true});
  });
  app.patch('/api/admin/config',admin,async(req,res)=>{
    const {school,title,accent}=req.body;let {logo}=req.body;
    if(typeof school!=='string'||school.length>100||typeof title!=='string'||!title.trim()||title.length>100||!/^#[0-9a-f]{6}$/i.test(accent||'')||typeof logo!=='string'||logo.length>100000 || (logo.length>16&&!/^data:image\/webp;base64,[A-Za-z0-9+/=]+$/.test(logo)))return res.status(400).json({error:'Invalid configuration'});
    if(logo.startsWith('data:')){try{const buffer=Buffer.from(logo.split(',')[1],'base64');if(buffer.subarray(0,4).toString()!=='RIFF'||buffer.subarray(8,12).toString()!=='WEBP')throw new Error('Invalid logo');const clean=await sharp(buffer,{limitInputPixels:1000000}).resize(96,96,{fit:'inside'}).webp().toBuffer();logo=`data:image/webp;base64,${clean.toString('base64')}`;}catch{return res.status(400).json({error:'Invalid logo image'});}}
    for(const [k,v]of Object.entries({school,title,accent,logo}))db.prepare('INSERT OR REPLACE INTO config VALUES(?,?)').run(k,v);
    res.json(config());
  });
  app.get('/api/health',(req,res)=>res.json({ok:true}));
  app.get('/api/{*path}',(_,res)=>res.status(404).json({error:'Not found'}));
  if(existsSync('dist')){app.use(express.static('dist',{dotfiles:'deny',index:false}));app.get(/^(?!\/api).*/,(req,res)=>allowedPage(req.path,variant)?res.sendFile(path.resolve('dist/index.html')):res.sendStatus(404));}
  app.use((err,req,res,next)=>res.status(err.code==='LIMIT_FILE_SIZE'?413:400).json({error:err.code==='LIMIT_FILE_SIZE'?'Each photo must be under 10 MB; total submission under 25 MB':'Upload failed. Maximum 10 JPEG, PNG or WebP photos.'}));
  return {app,db,objects};
}
