import {readFileSync} from 'node:fs';
export const release=JSON.parse(readFileSync(new URL('../app.config.json',import.meta.url),'utf8'));
export const variants={
 combined:{variant:'combined',name:'halloween-memory-galaxy-combined',title:'Halloween Memories & Memory Galaxy',brand:'Your school',dataDir:'data',apiPort:3001,devPort:5173},
 halloween:{variant:'halloween',name:'halloween-memories-standalone',title:'Halloween Memories',brand:'Your celebration',dataDir:'data-halloween',apiPort:3002,devPort:5174},
 galaxy:{variant:'galaxy',name:'memory-galaxy-standalone',title:'Memory Galaxy',brand:'Our memories',dataDir:'data-galaxy',apiPort:3003,devPort:5175}
};
export function allowedPage(pathname,variant=release.variant){return ['/', '/admin','/submit',...(variant==='combined'?['/halloween','/galaxy']:[])].includes(pathname.replace(/\/$/,'')||'/');}
