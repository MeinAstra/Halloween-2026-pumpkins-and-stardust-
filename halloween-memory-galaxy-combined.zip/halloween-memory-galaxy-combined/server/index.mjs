import {createApp} from './app.mjs';
import {release} from './config.mjs';
import {loadAdmin} from './admin.mjs';
const dataDir=process.env.DATA_DIR||release.dataDir;
const {app}=createApp({dataDir});
if(!loadAdmin(dataDir))console.warn('Administrator login disabled. Run npm run setup:admin locally (or -- --migrate-legacy for an existing development account).');
if(process.env.ADMIN_PASSWORD)console.warn('ADMIN_PASSWORD is no longer used. Migrate credentials locally and remove the old environment secret.');
app.listen(Number(process.env.PORT||release.apiPort),process.env.HOST||'127.0.0.1',()=>console.log(`${release.title}: server ready.`));
