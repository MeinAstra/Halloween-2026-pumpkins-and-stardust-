import {createApp} from './app.mjs';
import {createHash} from 'node:crypto';
import {writeFileSync} from 'node:fs';
import path from 'node:path';
import sharp from 'sharp';
const paths=process.argv.slice(2);
if(!paths.length)throw new Error('Usage: node server/seed.mjs /absolute/photo1.png /absolute/photo2.png ...');
const {db,objects}=createApp();
for(const [i,file]of paths.entries()){
 const id=createHash('sha256').update(`local-test-${i}`).digest('hex').slice(0,32);
 const image=sharp(file,{limitInputPixels:40000000}).rotate();
 writeFileSync(path.join(objects,`${id}-thumb.webp`),await image.clone().resize(480,360,{fit:'cover'}).webp({quality:82}).toBuffer(),{mode:0o600});
 writeFileSync(path.join(objects,`${id}-full.webp`),await image.clone().resize(2000,2000,{fit:'inside',withoutEnlargement:true}).webp({quality:90}).toBuffer(),{mode:0o600});
 db.prepare('INSERT OR REPLACE INTO photos(id,status,created,demo) VALUES(?,?,?,1)').run(id,'approved',Date.now()+i);
}
db.close();console.log(`Seeded ${paths.length} local test photos. Each test image maps to one memory star.`);
