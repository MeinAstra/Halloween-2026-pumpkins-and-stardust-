import readline from 'node:readline';
import {Writable} from 'node:stream';
import {existsSync,readFileSync,unlinkSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {DatabaseSync} from 'node:sqlite';
import {saveAdmin,adminPath} from './admin.mjs';
import {release} from './config.mjs';
export async function migrateLegacy(dataDir){
 const file=path.resolve(dataDir,'development-credentials.json');
 if(!existsSync(file))throw new Error('No legacy credential file exists. Run npm run setup:admin.');
 const legacy=JSON.parse(readFileSync(file,'utf8'));
 await saveAdmin(dataDir,legacy.username,legacy.password); // Keep the existing owner’s login, never print it.
 unlinkSync(file);
}
function terminalPrompts(){
 if(!process.stdin.isTTY||!process.stdout.isTTY)throw new Error('Use an interactive local terminal.');
 let hidden=false;
 const output=new Writable({write(chunk,encoding,callback){if(!hidden)process.stdout.write(chunk,encoding);callback();}});
 const rl=readline.createInterface({input:process.stdin,output,terminal:true});
 return {ask(label,secret=false){hidden=secret;return new Promise((resolve,reject)=>{rl.once('close',()=>reject(new Error('Setup cancelled.')));rl.question(secret?'':label,value=>{if(secret)process.stdout.write('\n');resolve(value);});if(secret)process.stdout.write(label);});},close(){hidden=false;rl.close();}};
}
export function revokeSessions(dataDir){
 const file=path.resolve(dataDir,'gallery.sqlite');if(!existsSync(file))return;
 const db=new DatabaseSync(file);try{if(db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='sessions'").get())db.exec('DELETE FROM sessions');}finally{db.close();}
}
async function main(){
 const dataDir=process.env.DATA_DIR||release.dataDir,args=process.argv.slice(2);
 if(args.some(a=>!['--reset','--migrate-legacy'].includes(a)))throw new Error('Usage: npm run setup:admin [-- --reset | --migrate-legacy]');
 if(args.includes('--migrate-legacy')){if(args.includes('--reset'))throw new Error('Choose migration or reset, not both.');await migrateLegacy(dataDir);}
 else{
  const replace=args.includes('--reset');if(existsSync(adminPath(dataDir))&&!replace)throw new Error('Administrator already exists. Use --reset to change it locally.');
  const prompts=terminalPrompts();
  try{const username=await prompts.ask('Choose administrator username: '),password=await prompts.ask('Choose a strong password (hidden): ',true),confirm=await prompts.ask('Confirm password (hidden): ',true);
   if(password!==confirm)throw new Error('Passwords did not match. Nothing changed.');await saveAdmin(dataDir,username,password,{replace});
  }finally{prompts.close();}
 }
 revokeSessions(dataDir);console.log('Administrator configured securely. Existing sessions revoked. Sign in at /admin using your chosen credentials.');
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(()=>{console.error('Administrator setup did not complete. Check the README, use an interactive terminal, a valid 3–64 character username and a unique 16–256 character password. Existing accounts require --reset; legacy accounts require --migrate-legacy.');process.exitCode=1;});
