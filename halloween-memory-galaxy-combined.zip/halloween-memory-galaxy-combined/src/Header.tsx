import {ArrowUpRight,ShieldCheck,Sparkles} from 'lucide-react';
import {standalone,general,release} from './release';
import type {Config} from './types';
export default function Header({config,current='home'}:{config?:Config;current?:'home'|'halloween'|'galaxy'}){
 return <header className={`header experience-header ${standalone?'standalone-header':''}`}><a className="brand" href="/" aria-label="Memory collection home"><span className="brand-icon">{config?.logo?.startsWith('data:')?<img src={config.logo} alt={general?'Collection logo':'Gallery logo'}/>:config?.logo||<Sparkles size={20}/>}</span><span>{config?.school||release.brand}<small>A COLLECTION OF OUR MOMENTS</small></span></a><nav aria-label="Main navigation">{!standalone&&<><a href="/halloween" aria-current={current==='halloween'?'page':undefined}>Halloween Memories</a><a href="/galaxy" aria-current={current==='galaxy'?'page':undefined}>Memory Galaxy</a></>}<a className="share-link" href="/submit">Share a memory <ArrowUpRight size={14}/></a><a className="admin-link" href="/admin" aria-label="Gallery administrator"><ShieldCheck size={17}/></a></nav></header>;
}
