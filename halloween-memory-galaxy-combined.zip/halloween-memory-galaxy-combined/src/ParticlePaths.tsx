import {useEffect,useMemo,useRef,useState} from 'react';
import {useFrame,useThree,type ThreeEvent} from '@react-three/fiber';
import {Billboard,Html} from '@react-three/drei';
import * as T from 'three';
import {memoryAnchor,pathSamples,type MemoryPath} from './shapes';
import type {Photo} from './types';

// Shared dotted-ribbon engine. A pair of instanced draws covers every curve;
// no image textures are loaded by the sculpture.
export function RibbonPath({paths,spacing=.075,particleSize=.018,glowIntensity=.22,animationSpeed=.3,reduced=false,color='#ffe4ad'}:{paths:MemoryPath[];spacing?:number;particleSize?:number;glowIntensity?:number;animationSpeed?:number;reduced?:boolean;color?:string}){
 const cores=useRef<T.InstancedMesh>(null),halos=useRef<T.InstancedMesh>(null);
 const points=useMemo(()=>pathSamples(paths,spacing),[paths,spacing]);
 const dummy=useMemo(()=>new T.Object3D(),[]),current=useRef<T.Vector3[]>([]);
 useEffect(()=>{
  const previous=current.current;
  current.current=points.map((point,i)=>previous.length?previous[i%previous.length].clone():point.clone());
 },[points]);
 useFrame(({clock},dt)=>{
  const alpha=reduced?1:1-Math.exp(-dt*4);
  points.forEach((target,i)=>{
   const p=current.current[i];if(!p)return;p.lerp(target,alpha);
   const pulse=reduced?1:.93+.07*Math.sin(clock.elapsedTime*animationSpeed-i*.13);
   dummy.position.copy(p);dummy.scale.setScalar(particleSize*pulse*(.85+.25*Math.sin(i*2.4)));dummy.updateMatrix();cores.current?.setMatrixAt(i,dummy.matrix);
   dummy.scale.multiplyScalar(2.6);dummy.updateMatrix();halos.current?.setMatrixAt(i,dummy.matrix);
  });
  if(cores.current)cores.current.instanceMatrix.needsUpdate=true;
  if(halos.current){halos.current.instanceMatrix.needsUpdate=true;const material=halos.current.material as T.MeshBasicMaterial;material.opacity=glowIntensity;}
 });
 return <><instancedMesh ref={cores} args={[undefined,undefined,points.length]} frustumCulled={false}><sphereGeometry args={[1,6,5]}/><meshBasicMaterial color={color} toneMapped={false}/></instancedMesh><instancedMesh ref={halos} args={[undefined,undefined,points.length]} frustumCulled={false}><sphereGeometry args={[1,6,5]}/><meshBasicMaterial color={color} transparent opacity={glowIntensity} depthWrite={false} blending={T.AdditiveBlending} toneMapped={false}/></instancedMesh></>;
}
export function MemoryParticle({photo,paths,onOpen,reduced,selected,onHover,sparkle=false}:{photo:Photo;paths:MemoryPath[];onOpen:(p:Photo)=>void;reduced:boolean;selected:boolean;onHover?:(hover:boolean)=>void;sparkle?:boolean}){
 const group=useRef<T.Group>(null),halo=useRef<T.Mesh>(null),targetMesh=useRef<T.Mesh>(null),[hover,setHover]=useState(false);
 const star=useMemo(()=>{const shape=new T.Shape();shape.moveTo(0,.15);shape.quadraticCurveTo(.023,.023,.11,0);shape.quadraticCurveTo(.023,-.023,0,-.15);shape.quadraticCurveTo(-.023,-.023,-.11,0);shape.quadraticCurveTo(-.023,.023,0,.15);return new T.ShapeGeometry(shape);},[]);
 useEffect(()=>()=>star.dispose(),[star]);
 const worldPosition=useMemo(()=>new T.Vector3(),[]);
 const position=useMemo(()=>memoryAnchor(photo.id,paths),[photo.id,paths]);const {size,camera,gl}=useThree();
 useEffect(()=>()=>{gl.domElement.style.cursor='';},[gl]);
 useFrame((_,dt)=>{
  if(!group.current)return;
  group.current.position.lerp(position,reduced?1:1-Math.exp(-dt*4));
  if(halo.current)halo.current.scale.setScalar(hover||selected?1.65:1);
  // Minimum ~32px hit diameter, independent of zoom or phone resolution.
  if(targetMesh.current){const distance=camera.position.distanceTo(group.current.getWorldPosition(worldPosition));const worldPerPixel=2*distance*Math.tan(T.MathUtils.degToRad((camera as T.PerspectiveCamera).fov/2))/size.height;targetMesh.current.scale.setScalar(Math.max(.14,worldPerPixel*16));}
 });
 function open(e:ThreeEvent<MouseEvent>){e.stopPropagation();if(e.delta<5)onOpen(photo);}
 return <group ref={group} position={position}><mesh ref={halo}><sphereGeometry args={[.076,12,8]}/><meshBasicMaterial color={hover||selected?'#fff9e8':'#ffe7b4'} transparent opacity={hover||selected ? .46 : .18} depthWrite={false} blending={T.AdditiveBlending}/></mesh><Billboard>{sparkle?<group scale={hover||selected?1.3:1}><mesh geometry={star}><meshBasicMaterial color="#fff2c9" toneMapped={false} side={T.DoubleSide}/></mesh><mesh geometry={star} position={[.15,.13,0]} scale={.4}><meshBasicMaterial color="#f0d39b" toneMapped={false} side={T.DoubleSide}/></mesh></group>:<mesh><sphereGeometry args={[hover||selected ? .044 : .032,10,8]}/><meshBasicMaterial color="#fff2cf" toneMapped={false}/></mesh>}</Billboard><mesh ref={targetMesh} onClick={open} onPointerOver={e=>{e.stopPropagation();setHover(true);onHover?.(true);gl.domElement.style.cursor='pointer';}} onPointerOut={()=>{setHover(false);onHover?.(false);gl.domElement.style.cursor='';}}><sphereGeometry args={[1,12,8]}/><meshBasicMaterial transparent opacity={0} depthWrite={false} colorWrite={false}/></mesh>{hover&&<Html center position={[0,.25,0]} style={{pointerEvents:'none',whiteSpace:'nowrap'}}><span className="particle-hint">Open a memory <span>↗</span></span></Html>}</group>;
}
