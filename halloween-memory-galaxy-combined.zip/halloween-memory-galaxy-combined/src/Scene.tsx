import {Suspense,useEffect,useMemo,useRef} from 'react';
import {Canvas,useFrame,useThree} from '@react-three/fiber';
import {ContactShadows,Environment,Lightformer,OrbitControls,Sparkles} from '@react-three/drei';
import * as T from 'three';
import {type Mode} from './shapes';
import {RibbonPath,MemoryParticle} from './ParticlePaths';
import {PumpkinModel,usePumpkin} from './Sculptures';
import Stardust from './Stardust';
import type {Photo} from './types';

function Camera({reset,auto,reduced,galaxy,view}:{reset:number;auto:boolean;reduced:boolean;galaxy:boolean;view:'overview'|'near'}){
 const controls=useRef<any>(null),resetting=useRef(true);const {camera,size}=useThree();
 // Fit the sculpture to the smaller viewport dimension, including portrait phones.
 const home=useMemo(()=>new T.Vector3(0,.55,Math.max(galaxy?(view==='near'?7.8:11.6):10.3,(galaxy?(view==='near'?7:9.2):8.6)/(size.width/size.height))),[size.width,size.height,galaxy,view]);
 useEffect(()=>{resetting.current=true;},[reset,home]);
 useFrame((_,dt)=>{if(controls.current)controls.current.target.clampLength(0,2.5);if(resetting.current&&controls.current){camera.position.lerp(home,reduced?1:1-Math.exp(-dt*5));controls.current.target.lerp(new T.Vector3(0,.05,0),reduced?1:1-Math.exp(-dt*5));if(camera.position.distanceTo(home)<.02)resetting.current=false;controls.current.update();}});
 return <OrbitControls ref={controls} makeDefault enableDamping dampingFactor={.06} minDistance={6} maxDistance={24} minPolarAngle={.3} maxPolarAngle={Math.PI-.3} autoRotate={auto&&!reduced} autoRotateSpeed={.26} onStart={()=>{resetting.current=false;}}/>;
}
function HalloweenInstallation({photos,mode,onOpen,reduced,selectedId,low}:{photos:Photo[];mode:Mode;onOpen:(p:Photo)=>void;reduced:boolean;selectedId:string|null;low:boolean}){
 const {model,paths:pumpkin}=usePumpkin();
 const memoryPaths=useMemo(()=>pumpkin.filter(p=>p.curve.getPointAt(.5).z>0),[pumpkin]);
 return <><PumpkinModel model={model} mode={mode} reduced={reduced}/>{mode==='pumpkin'?<><RibbonPath paths={pumpkin} spacing={low?.1:.075} particleSize={.019} glowIntensity={.12} reduced={reduced} color="#fff0c9"/>{photos.map(photo=><MemoryParticle key={photo.id} photo={photo} paths={memoryPaths} reduced={reduced} selected={selectedId===photo.id} onOpen={onOpen}/>)}{!reduced&&<Sparkles count={low?25:55} scale={[13,8,10]} size={1.3} speed={.1} opacity={.22} color="#ead6b1"/>}</>:<Stardust key={mode} kind="mask" photos={photos} onOpen={onOpen} selectedId={selectedId} reduced={reduced} low={low}/>}</>;

}
function Installation(props:{photos:Photo[];mode:Mode;onOpen:(p:Photo)=>void;reduced:boolean;selectedId:string|null;low:boolean}){
 return props.mode==='chaos'?<Stardust kind="garden" photos={props.photos} onOpen={props.onOpen} selectedId={props.selectedId} reduced={props.reduced} low={props.low}/>:<HalloweenInstallation {...props}/>;
}
export default function Scene({photos,mode,onOpen,reset,auto,reduced,selectedId,view='overview'}:{photos:Photo[];mode:Mode;onOpen:(p:Photo)=>void;reset:number;auto:boolean;reduced:boolean;selectedId:string|null;view?:'overview'|'near'}){
 const low=window.innerWidth<700 || (navigator.hardwareConcurrency||4)<=4;
 return <Canvas camera={{position:[0,.55,11],fov:43,near:.1,far:65}} dpr={[1,low?1.25:1.65]} gl={{antialias:true,alpha:true,powerPreference:'high-performance'}} onCreated={({gl})=>{gl.domElement.addEventListener('webglcontextlost',()=>window.dispatchEvent(new Event('gallery-webgl-lost')));}}>
 <ambientLight intensity={.6} color="#fff3df"/><hemisphereLight args={['#e4ecff','#c1a18d',.65]}/><directionalLight position={[-3,6,7]} intensity={1.8} color="#fff1d9"/><directionalLight position={[5,2,-3]} intensity={1.5} color="#d5d8fa"/>
 <Suspense fallback={null}>{mode!=='chaos'&&<Environment resolution={64} frames={1}><Lightformer form="rect" intensity={2} color="#fff1dc" scale={[8,6,1]} position={[-4,4,5]}/><Lightformer form="rect" intensity={1} color="#c7c5e7" scale={[5,7,1]} position={[4,1,-4]}/></Environment>}<Installation photos={photos} mode={mode} onOpen={onOpen} reduced={reduced} selectedId={selectedId} low={low}/>{mode==='pumpkin'&&<ContactShadows position={[0,-1.95,0]} opacity={.17} scale={14} blur={3} far={5} resolution={256}/>}</Suspense><Camera galaxy={mode==='chaos'} view={view} reset={reset} auto={auto&&selectedId===null} reduced={reduced}/></Canvas>;
}
