import {useEffect,useMemo,useRef} from 'react';
import {useGLTF} from '@react-three/drei';
import {useFrame} from '@react-three/fiber';
import * as T from 'three';
import {pumpkinPaths,type Mode} from './shapes';

export function usePumpkin(){
 const {scene}=useGLTF('/models/pumpkin.glb');
 return useMemo(()=>{
  const model=scene.clone(true);const box=new T.Box3().setFromObject(model),size=box.getSize(new T.Vector3());
  const scale=4.7/Math.max(size.x,size.z),center=box.getCenter(new T.Vector3());center.y=box.min.y+size.y*.43;
  model.position.copy(center.multiplyScalar(-scale));model.scale.setScalar(scale);
  model.traverse(object=>{if(object instanceof T.Mesh){const geometry=object.geometry.clone(),p=geometry.attributes.position,colors=[];geometry.computeBoundingBox();const bounds=geometry.boundingBox!;
   for(let i=0;i<p.count;i++){const h=(p.getY(i)-bounds.min.y)/(bounds.max.y-bounds.min.y),color=new T.Color(h>.855?'#829b5e':'#ed8e3d');if(h<.855)color.lerp(new T.Color('#f3a45c'),Math.max(0,h-.25)*.23);colors.push(color.r,color.g,color.b);}
   geometry.setAttribute('color',new T.Float32BufferAttribute(colors,3));object.geometry=geometry;object.material=new T.MeshStandardMaterial({vertexColors:true,roughness:.94,metalness:0});object.castShadow=true;object.receiveShadow=true;
  }});
  model.updateMatrixWorld(true);
  return {model,paths:pumpkinPaths(model)};
 },[scene]);
}
export function PumpkinModel({model,mode,reduced}:{model:T.Object3D;mode:Mode;reduced:boolean}){
 const ref=useRef<T.Group>(null);
 useEffect(()=>()=>{model.traverse(o=>{if(o instanceof T.Mesh){o.geometry.dispose();(o.material as T.Material).dispose();}});},[model]);
 const face=useMemo(()=>{
  const ray=new T.Raycaster();function front(x:number,y:number){ray.set(new T.Vector3(x,y,8),new T.Vector3(0,0,-1));return (ray.intersectObject(model,true)[0]?.point.clone()||new T.Vector3(x,y,2)).add(new T.Vector3(0,0,.035));}
  return {nose:front(0,-.32),eyes:[front(-.43,-.17),front(.43,-.17)],cheeks:[front(-.76,-.39),front(.76,-.39)],smile:new T.TubeGeometry(new T.CatmullRomCurve3(Array.from({length:17},(_,i)=>{const t=i/16;return front((t-.5)*.44,-.4-.16*Math.sin(t*Math.PI));})),32,.018,6,false)};
 },[model]);
 const nose=useMemo(()=>{
  const shape=new T.Shape();shape.moveTo(-.065,.041);shape.quadraticCurveTo(-.083,.047,-.069,.023);shape.lineTo(-.013,-.055);shape.quadraticCurveTo(0,-.073,.013,-.055);shape.lineTo(.069,.023);shape.quadraticCurveTo(.083,.047,.065,.041);shape.closePath();
  const g=new T.ExtrudeGeometry(shape,{depth:.023,bevelEnabled:true,bevelSize:.009,bevelThickness:.009,bevelSegments:3,steps:1,curveSegments:10});return g;
 },[]);
 useEffect(()=>()=>{face.smile.dispose();nose.dispose();},[face,nose]);
 useFrame((_,dt)=>{if(ref.current){const scale=T.MathUtils.damp(ref.current.scale.x,mode==='pumpkin'?1:.001,reduced?100:5,dt);ref.current.scale.setScalar(scale);ref.current.visible=scale>.01;}});
 return <group ref={ref}><primitive object={model} onClick={(e:{stopPropagation:()=>void})=>e.stopPropagation()} dispose={null}/>{face.eyes.map((p,i)=><mesh key={i} position={p}><sphereGeometry args={[.08,20,16]}/><meshStandardMaterial color="#593d36" roughness={1}/></mesh>)}{face.cheeks.map((p,i)=><mesh key={i} position={p} scale={[1,.55,.16]}><sphereGeometry args={[.16,16,12]}/><meshStandardMaterial color="#eda391" roughness={1}/></mesh>)}<mesh position={face.nose} geometry={nose}><meshStandardMaterial color="#593d36" roughness={1}/></mesh><mesh geometry={face.smile}><meshStandardMaterial color="#654533" roughness={1}/></mesh></group>;
}
