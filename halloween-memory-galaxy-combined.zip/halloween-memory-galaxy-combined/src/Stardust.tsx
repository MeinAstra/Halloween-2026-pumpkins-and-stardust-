import {useEffect,useLayoutEffect,useMemo,useRef,useState} from 'react';
import {useFrame,useThree} from '@react-three/fiber';
import * as T from 'three';
import {createPorcelainMask,maskContours,sampleMask,seededRandom} from './porcelainMask';
import {createGarden,gardenPaths} from './celestialGarden';
import {MemoryParticle} from './ParticlePaths';
import {memoryAnchor} from './shapes';
import type {Photo} from './types';

const vertex = `
attribute float aSize; attribute float aSeed; attribute float aEdge;
uniform float uTime; uniform float uPixel; uniform float uHeight; uniform float uKind;
uniform vec3 uMemory; uniform float uResponse;
varying vec3 vColor; varying float vAlpha; varying float vProminent;
void main(){
 vec3 p=position;

 if(uKind<.5){
  p+=vec3(sin(uTime*.07+aSeed),cos(uTime*.09+aSeed*1.7),sin(uTime*.06+aSeed*2.1))*.045;
 }else{
  // Rare edge grains lift and return over a long, smooth cycle.
  float release=pow(max(0.,sin(uTime*.12+aSeed*3.)),14.)*aEdge*.035;
  p+=normal*release;
 }
 float nearby=exp(-dot(p-uMemory,p-uMemory)*2.5)*uResponse;
 p+=normalize(p-uMemory+vec3(.001))*(nearby*.025);
 vec4 mv=modelViewMatrix*vec4(p,1.);
 gl_Position=projectionMatrix*mv;
 gl_PointSize=clamp(aSize*uHeight*uPixel*(uKind<.5?1.6:1.45)/(-mv.z),.65,10.*uPixel);
 float twinkle=.85+.15*sin(uTime*(.35+fract(aSeed)*.35)+aSeed*5.);
 if(uKind>.5){
  vec3 n=normalize(normalMatrix*normal);
  float lighting=.2+.8*max(0.,dot(n,normalize(vec3(-.45,.6,1.))));
  float facing=.4+.6*max(0.,n.z);
  vColor=mix(vec3(.73,.79,.84),vec3(.972,.949,.906),lighting);
  vAlpha=(.4+lighting*.5)*facing*twinkle+nearby*.12;
 }else{vColor=color;vAlpha=(.56+.3*fract(aSeed))*twinkle+nearby*.2;}
 vProminent=step(.09,aSize);vColor*=1.+nearby*.2;
}`;
const fragment = `
varying vec3 vColor; varying float vAlpha; varying float vProminent;
void main(){
 float r=length(gl_PointCoord-.5)*2.;if(r>1.)discard;
 float core=exp(-r*r*8.);
 float halo=exp(-r*r*2.)*mix(.15,.32,vProminent);
 float alpha=(core+halo)*vAlpha;
 gl_FragColor=vec4(vColor,alpha);
 #include <tonemapping_fragment>
 #include <colorspace_fragment>
}`;
export default function Stardust({kind,photos,onOpen,selectedId,reduced,low}:{kind:'mask'|'garden';photos:Photo[];onOpen:(p:Photo)=>void;selectedId:string|null;reduced:boolean;low:boolean}){
 const started=useRef<number|null>(null),group=useRef<T.Group>(null),material=useRef<T.ShaderMaterial>(null),[hovered,setHovered]=useState<string|null>(null),{gl,size}=useThree();
 useLayoutEffect(()=>{if(group.current){group.current.position.set(kind==='mask'?.3:0,kind==='mask'?-.45:0,0);group.current.rotation.set(0,kind==='mask'?.32:0,0);}},[kind]);
 const paths=useMemo(()=>kind==='mask'?maskContours():gardenPaths(),[kind]);
 const geometry=useMemo(()=>{
  const count=kind==='mask'?(low?20000:44000):(low?10500:26000),g=new T.BufferGeometry(),random=seededRandom(35);
  if(kind==='mask'){
   const shell=createPorcelainMask(),data=sampleMask(shell,count);shell.dispose();
   g.setAttribute('color',new T.BufferAttribute(new Float32Array(count*3).fill(1),3));
   g.setAttribute('position',new T.BufferAttribute(data.positions,3));g.setAttribute('normal',new T.BufferAttribute(data.normals,3));g.setAttribute('aEdge',new T.BufferAttribute(data.edge,1));
   g.setAttribute('aSize',new T.Float32BufferAttribute(Array.from({length:count},()=>.016+random()**2*.023),1));
   g.setAttribute('aSeed',new T.Float32BufferAttribute(Array.from({length:count},()=>random()*100),1));
  }else{
   const data=createGarden(count);g.setAttribute('position',new T.BufferAttribute(data.positions,3));g.setAttribute('color',new T.BufferAttribute(data.colors,3));g.setAttribute('aSize',new T.BufferAttribute(data.sizes,1));g.setAttribute('aSeed',new T.BufferAttribute(data.seeds,1));g.setAttribute('aEdge',new T.BufferAttribute(new Float32Array(count),1));
  }
  return g;
 },[kind,low]);
 const uniforms=useMemo(()=>({uTime:{value:0},uPixel:{value:1},uHeight:{value:500},uKind:{value:kind==='mask'?1:0},uMemory:{value:new T.Vector3(100,100,100)},uResponse:{value:0}}),[kind]);
 useEffect(()=>()=>geometry.dispose(),[geometry]);
 const active=selectedId||hovered,anchor=useMemo(()=>active?memoryAnchor(active,paths):new T.Vector3(100,100,100),[active,paths]);
 useFrame(({clock,pointer},dt)=>{
  if(started.current===null)started.current=clock.elapsedTime;
  const t=reduced?0:clock.elapsedTime-started.current;
  if(material.current){const u=material.current.uniforms;u.uTime.value=t;u.uPixel.value=gl.getPixelRatio();u.uHeight.value=size.height;u.uMemory.value.lerp(anchor,1-Math.exp(-dt*5));u.uResponse.value=T.MathUtils.damp(u.uResponse.value,active?1:0,4,dt);}
  if(group.current){const mask=kind==='mask';group.current.rotation.y=T.MathUtils.damp(group.current.rotation.y,mask?.32+(reduced?0:Math.sin(t*.09)*.035):reduced?0:pointer.x*.035,3,dt);group.current.rotation.z=mask?0:t*.006;group.current.rotation.x=T.MathUtils.damp(group.current.rotation.x,mask?-.025:reduced?0:-pointer.y*.022,3,dt);group.current.position.y=(mask?-.45:0)+(reduced?0:Math.sin(t*.18)*.025);}
 });
 return <group ref={group} scale={kind==='mask'?1.35:1}><points geometry={geometry} frustumCulled={false}><shaderMaterial ref={material} uniforms={uniforms} vertexShader={vertex} fragmentShader={fragment} transparent depthWrite={false} blending={T.NormalBlending} vertexColors toneMapped={false}/></points>{photos.map(photo=><MemoryParticle key={photo.id} photo={photo} paths={paths} reduced={reduced} selected={selectedId===photo.id} sparkle={kind==='garden'} onOpen={onOpen} onHover={value=>setHovered(value?photo.id:null)}/>)}</group>;
}
