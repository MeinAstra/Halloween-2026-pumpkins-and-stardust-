import * as T from 'three';
import {seededRandom} from './porcelainMask.ts';
import {spline} from './shapes.ts';
const phases=[0,2.95,5.1];
function armPoint(r:number,phase:number){const a=Math.log1p(r)*3.25+phase;return new T.Vector3(Math.cos(a)*r,Math.sin(a)*r*.7,Math.sin(a)*r*.42);}
export function gardenPaths(){
 // Invisible, stable photo anchors; the visible arms are broad surface clouds.
 return phases.map((phase,j)=>spline(`galaxy-arm-${j}`,Array.from({length:48},(_,i)=>armPoint(.65+i/47*2.7,phase))));
}
export function createGarden(count:number){
 const random=seededRandom(793),positions=new Float32Array(count*3),sizes=new Float32Array(count),seeds=new Float32Array(count),colors=new Float32Array(count*3);
 const ivory=new T.Color('#fff1d5'),gold=new T.Color('#edc78c'),blue=new T.Color('#b4ccef'),lavender=new T.Color('#b2a0d4');
 const normal=()=>Math.sqrt(-2*Math.log(Math.max(.000001,random())))*Math.cos(random()*Math.PI*2);
 for(let i=0;i<count;i++){
  const layer=random(),p=new T.Vector3();let color:T.Color,diffuse=false;
  if(layer<.25){
   // Warm, softly ellipsoidal bulge anchors the galaxy visually.
   p.set(normal()*.43,normal()*.32,normal()*.36);color=gold.clone().lerp(ivory,random()*.7);
  }else if(layer<.85){
   const r=.45+Math.pow(random(),.72)*3.0,choice=random(),phase=phases[choice<.46?0:choice<.88?1:2];p.copy(armPoint(r,phase));
   const width=.06+.075*r;p.x+=normal()*width;p.y+=normal()*width;p.z+=normal()*(.13+.045*r);
   color=gold.clone().lerp(random()<.55?blue:lavender,Math.min(.85,r/3.8));
  }else{
   diffuse=true;p.set(normal()*2.25,normal()*1.5,normal()*1.2-.4);color=(random()<.5?blue:lavender).clone().multiplyScalar(.55);
  }
  positions.set(p.toArray(),i*3);const prominent=random()>.999;
  sizes[i]=diffuse?.012+random()*.015:prominent?.11+random()*.06:.014+random()**2*.041;
  seeds[i]=random()*100;colors.set(color.multiplyScalar(.82+random()*.25).toArray(),i*3);
 }
 return {positions,sizes,seeds,colors};
}
