import * as T from 'three';
import {MeshSurfaceSampler} from 'three/addons/math/MeshSurfaceSampler.js';
import {spline,type MemoryPath} from './shapes.ts';

// Hand-authored upper half-mask. The outline stops at the cheek/nose fracture;
// the single aperture is triangulated as a hole through both shell surfaces.
const outline = [[-.26,2.04],[.46,1.94],[.93,1.57],[1.06,1.21],[.77,.98],[.51,.74],[.42,.4],[.46,.06],[.51,-.27],[.59,-.48],[.58,-.61],[.47,-.74],[.26,-.82],[.1,-.94],[-.1,-.91],[-.46,-.99],[-.84,-1.14],[-1.26,-1.13],[-1.47,-.72],[-1.62,-.1],[-1.65,.65],[-1.49,1.23],[-1.07,1.7],[-.65,1.94]];
const eye = [[-1.2,-.43],[-1.15,-.1],[-.94,.12],[-.61,.2],[-.34,.12],[-.29,-.1],[-.5,-.27],[-.87,-.4]];
const gauss=(x:number,y:number,cx:number,cy:number,sx:number,sy:number)=>Math.exp(-(((x-cx)/sx)**2+((y-cy)/sy)**2));
export function maskDepth(x:number,y:number){
 return .24-.43*(x+.25)**2-.065*(y-.6)**2
  + .25*gauss(x,y,-.72,.42,.8,.22) // brow ridge
  -.19*gauss(x,y,-.73,-.1,.57,.33) // recessed orbit
  + .42*gauss(x,y,.16,.07,.3,.9) // nasal bridge
  + .62*gauss(x,y,.32,-.5,.4,.34) // protruding nose tip
  + .14*gauss(x,y,.03,-.66,.25,.18) // ala / nostril edge
  -.12*gauss(x,y,.12,-.75,.09,.06)
  + .12*gauss(x,y,-.8,-.7,.55,.4);
}
function outlineCurve(points:number[][]){return new T.CatmullRomCurve3(points.map(([x,y])=>new T.Vector3(x,y,0)),true,'centripetal');}
const outer=outlineCurve(outline),aperture=outlineCurve(eye);
export function maskContours():MemoryPath[]{
 return [spline('porcelain-edge',outer.getSpacedPoints(150).slice(0,-1).map(p=>new T.Vector3(p.x,p.y,maskDepth(p.x,p.y))),true),spline('porcelain-eye',aperture.getSpacedPoints(72).slice(0,-1).map(p=>new T.Vector3(p.x,p.y,maskDepth(p.x,p.y)+.012)),true),spline('porcelain-nose',[[.18,.8],[.12,.45],[.12,.08],[.22,-.28],[.32,-.48],[.36,-.59],[.31,-.69]].map(([x,y])=>new T.Vector3(x,y,maskDepth(x,y)+.025)))];
}
export function createPorcelainMask(){
 const boundary=outer.getSpacedPoints(100).slice(0,-1).map(p=>new T.Vector2(p.x,p.y));
 const opening=aperture.getSpacedPoints(56).slice(0,-1).map(p=>new T.Vector2(p.x,p.y));
 if(!T.ShapeUtils.isClockWise(boundary))boundary.reverse();if(T.ShapeUtils.isClockWise(opening))opening.reverse();
 const vertices=[...boundary,...opening],triangles=T.ShapeUtils.triangulateShape(boundary,[opening]);
 const positions:number[]=[],normals:number[]=[];
 function surface(p:T.Vector2,back=false){const e=.001,dx=(maskDepth(p.x+e,p.y)-maskDepth(p.x-e,p.y))/(2*e),dy=(maskDepth(p.x,p.y+e)-maskDepth(p.x,p.y-e))/(2*e);const n=new T.Vector3(-dx,-dy,1).normalize();return {p:new T.Vector3(p.x,p.y,maskDepth(p.x,p.y)).addScaledVector(n,back?-.09:0),n:back?n.negate():n};}
 function addTriangle(a:T.Vector2,b:T.Vector2,c:T.Vector2,depth:number){
  if(depth){const ab=a.clone().add(b).multiplyScalar(.5),bc=b.clone().add(c).multiplyScalar(.5),ca=c.clone().add(a).multiplyScalar(.5);addTriangle(a,ab,ca,depth-1);addTriangle(ab,b,bc,depth-1);addTriangle(ca,bc,c,depth-1);addTriangle(ab,bc,ca,depth-1);return;}
  for(const back of [false,true])for(const v of back?[c,b,a]:[a,b,c]){const s=surface(v,back);positions.push(...s.p.toArray());normals.push(...s.n.toArray());}
 }
 for(const [a,b,c]of triangles)addTriangle(vertices[a],vertices[b],vertices[c],4);
 for(const loop of [boundary,opening])for(let i=0;i<loop.length;i++){
  const a=surface(loop[i]),b=surface(loop[(i+1)%loop.length]),c=surface(loop[i],true),d=surface(loop[(i+1)%loop.length],true),normal=new T.Vector3().crossVectors(b.p.clone().sub(a.p),c.p.clone().sub(a.p)).normalize();
  for(const p of [a.p,b.p,c.p,b.p,d.p,c.p]){positions.push(...p.toArray());normals.push(...normal.toArray());}
 }
 const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(positions,3));geometry.setAttribute('normal',new T.Float32BufferAttribute(normals,3));geometry.computeBoundingBox();return geometry;
}
export function seededRandom(seed=918273){return ()=>{seed=(Math.imul(1664525,seed)+1013904223)>>>0;return seed/4294967296;};}
export function sampleMask(geometry:T.BufferGeometry,count:number){
 const sampler=new MeshSurfaceSampler(new T.Mesh(geometry)).setRandomGenerator(seededRandom(45)).build(),positions=new Float32Array(count*3),normals=new Float32Array(count*3),edge=new Float32Array(count),p=new T.Vector3(),n=new T.Vector3(),contours=maskContours();
 for(let i=0;i<count;i++){
  if(i<count*.13){const path=contours[i%contours.length],t=(i*.61803398875)%1;p.copy(path.curve.getPointAt(t));const e=.001;n.set(-(maskDepth(p.x+e,p.y)-maskDepth(p.x-e,p.y))/(2*e),-(maskDepth(p.x,p.y+e)-maskDepth(p.x,p.y-e))/(2*e),1).normalize();edge[i]=1;}
  else sampler.sample(p,n);
  positions.set(p.toArray(),i*3);normals.set(n.toArray(),i*3);
 }
 return {positions,normals,edge};
}
