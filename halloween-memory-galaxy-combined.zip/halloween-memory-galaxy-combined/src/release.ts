import config from '../app.config.json';
export const release=config;
export const standalone=release.variant!=='combined';
export const general=release.variant==='galaxy';
export const defaultConfig={school:release.brand,title:general?'Memory Galaxy':'Halloween Memories',accent:'#ef9b54',logo:''};
export const photoLabel=general?'Memory':'School memory';
export const homeLabel=standalone?'Back to the gallery':'Back to the experiences';
export const changeChannel=`${release.name}-photos`;
