import * as T from 'three';
export type Mode = 'pumpkin' | 'mask' | 'chaos';
export type MemoryPath = { id: string; curve: T.CatmullRomCurve3; closed: boolean };
export function spline(id: string, points: T.Vector3[], closed = false): MemoryPath {
  return { id, curve: new T.CatmullRomCurve3(points, closed, 'centripetal'), closed };
}
export function pathSamples(paths: MemoryPath[], spacing=.075) {
 return paths.flatMap(path=>path.curve.getSpacedPoints(Math.max(8,Math.ceil(path.curve.getLength()/spacing))).slice(0,path.closed?-1:undefined));
}
export function hashId(id:string) {let h=2166136261;for(const c of id){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
export function memoryAnchor(id:string,paths:MemoryPath[]) {
 const hash=hashId(id),path=paths[hash%paths.length];
 return path.curve.getPointAt(.05+((hash>>>8)%100000)/100000*.9);
}
// Surface samples are raycast against the imported, normalized asset. Curves follow
// its actual recessed valleys rather than an assumed sphere or a separate proxy.
export function pumpkinPaths(body:T.Object3D):MemoryPath[] {
 body.updateWorldMatrix(true,true);
 const box=new T.Box3().setFromObject(body);
 box.max.y=box.min.y+(box.max.y-box.min.y)*.85;
 const center=box.getCenter(new T.Vector3()),size=box.getSize(new T.Vector3());
 const ray=new T.Raycaster(),direction=new T.Vector3(),origin=new T.Vector3();
 function surface(angle:number,y:number){
  direction.set(-Math.sin(angle),0,-Math.cos(angle));origin.set(center.x+Math.sin(angle)*8,y,center.z+Math.cos(angle)*8);
  ray.set(origin,direction);const hit=ray.intersectObject(body,true)[0];
  return hit?hit.point.clone().addScaledVector(direction,-.065):null;
 }
 const radii=Array.from({length:240},(_,i)=>surface(i/240*Math.PI*2,center.y)?.distanceTo(center)??8);
 const valleys=radii.map((r,i)=>r<radii[(i+239)%240]&&r<=radii[(i+1)%240]?i:-1).filter(i=>i>=0);
 const angles:number[]=[];
 for(const i of valleys.sort((a,b)=>radii[a]-radii[b]))if(angles.every(a=>Math.abs(Math.atan2(Math.sin(a-i/240*Math.PI*2),Math.cos(a-i/240*Math.PI*2)))>.38))angles.push(i/240*Math.PI*2);
 return angles.slice(0,12).sort((a,b)=>a-b).map((angle,i)=>{
  const points=Array.from({length:72},(_,j)=>surface(angle,box.min.y+size.y*(.08+.84*j/71))).filter((p):p is T.Vector3=>!!p);
  return spline(`groove-${i}`,points);
 }).filter(p=>p.curve.points.length>3);
}
