import 'three/addons/math/MeshSurfaceSampler.js';
// Present in the installed Three.js runtime; omitted by the current @types package.
declare module 'three/addons/math/MeshSurfaceSampler.js' {
 interface MeshSurfaceSampler { setRandomGenerator(random:()=>number):this; }
}
