import {changeChannel} from './release';
export type Photo={id:string;thumb:string;full:string;status?:string;demo:boolean;caption?:string;uploadedAt?:string};
export type Config={school:string;title:string;accent:string;logo:string};
export async function api(url:string,options?:RequestInit){const r=await fetch(url,{cache:'no-store',...options});const data=await r.json();if(!r.ok)throw new Error(data.error||'Request failed');return data;}
export const json=(method:string,body:unknown)=>({method,headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});

export function notifyPhotoChanges(){if(typeof BroadcastChannel!=='undefined'){const channel=new BroadcastChannel(changeChannel);channel.postMessage('changed');channel.close();}}
