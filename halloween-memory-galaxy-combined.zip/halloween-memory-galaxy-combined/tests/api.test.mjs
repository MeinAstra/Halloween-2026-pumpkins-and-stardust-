import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import sharp from 'sharp';
import {createApp} from '../server/app.mjs';
import {testAdmin} from './helpers.mjs';
const dataDir=mkdtempSync(path.join(tmpdir(),'halloween-test-'));
const credentials=await testAdmin(dataDir);
const {app,db}=createApp({dataDir,variant:'combined'});
let image,agent,id;
before(async()=>{image=await sharp({create:{width:80,height:60,channels:3,background:'#ff8800'}}).png().toBuffer();agent=request.agent(app);});
after(()=>{db.close();rmSync(dataDir,{recursive:true,force:true});});
test('public collection starts empty',async()=>{const r=await request(app).get('/api/gallery').expect(200);assert.equal(r.body.photos.length,0);});
test('anonymous users cannot inspect or mutate moderation',async()=>{await request(app).get('/api/admin/photos').expect(401);await request(app).patch('/api/admin/photos').send({ids:['a'.repeat(32)],status:'approved'}).expect(401);await request(app).patch('/api/admin/config').send({school:'X'}).expect(401);});
test('uploads require consent and actual image decoding',async()=>{await request(app).post('/api/submissions').attach('photos',image,{filename:'test.png',contentType:'image/png'}).expect(400);await request(app).post('/api/submissions').field('consent','true').attach('photos',Buffer.from('not an image'),{filename:'fake.png',contentType:'image/png'}).expect(400);await request(app).post('/api/submissions').field('consent','true').attach('photos',image,{filename:'test.gif',contentType:'image/gif'}).expect(400);});
test('upload size and quantity limits enforced on server',async()=>{await request(app).post('/api/submissions').field('consent','true').attach('photos',Buffer.alloc(10*1024*1024+1),{filename:'big.png',contentType:'image/png'}).expect(413);let r=request(app).post('/api/submissions').field('consent','true');for(let i=0;i<11;i++)r=r.attach('photos',image,{filename:`${i}.png`,contentType:'image/png'});await r.expect(400);});
test('submitted image stays private until approved; filenames are replaced',async()=>{const r=await request(app).post('/api/submissions').field('consent','true').attach('photos',image,{filename:'student-secret-name.png',contentType:'image/png'}).expect(201);assert.equal(r.body.status,'pending');id=db.prepare('SELECT id FROM photos').get().id;assert.match(id,/^[a-f0-9]{32}$/);await request(app).get(`/api/photos/${id}/thumb`).expect(401);assert.equal((await request(app).get('/api/gallery')).body.photos.length,0);});
test('login, private review, approve, hide and delete work on the server',async()=>{await agent.post('/api/login').send({username:'admin',password:'incorrect'}).expect(401);const creds=credentials;const r=await agent.post('/api/login').send(creds).expect(200);assert.match(r.headers['set-cookie'][0],/HttpOnly/);assert.match(r.headers['set-cookie'][0],/SameSite=Strict/);await agent.get(`/api/photos/${id}/thumb`).expect(200);await agent.patch('/api/admin/photos').send({ids:[id],status:'approved'}).expect(200);assert.equal((await request(app).get('/api/gallery')).body.photos.length,1);const full=await request(app).get(`/api/photos/${id}/full`).expect(200);assert.equal(full.headers['content-type'],'image/webp');await agent.patch('/api/admin/photos').send({ids:[id],status:'hidden'}).expect(200);await request(app).get(`/api/photos/${id}/thumb`).expect(401);assert.equal((await request(app).get('/api/gallery')).body.photos.length,0);await agent.patch('/api/admin/photos').send({ids:[id],status:'deleted'}).expect(200);await request(app).get(`/api/photos/${id}/thumb`).expect(404);});
test('configuration validation, origin protection, logout revocation',async()=>{await agent.patch('/api/admin/config').set('Origin','https://hostile.example').send({}).expect(403);await agent.patch('/api/admin/config').send({school:'A school',title:'Our night',accent:'#ffaa22',logo:'HM'}).expect(200);assert.equal((await request(app).get('/api/gallery')).body.config.school,'A school');await agent.patch('/api/admin/config').send({school:'A',title:'Title',accent:'invalid',logo:''}).expect(400);await agent.post('/api/logout').expect(200);await agent.get('/api/admin/photos').expect(401);});
test('path traversal and unexpected variants cannot access objects',async()=>{await request(app).get('/api/photos/not-an-id/full').expect(404);await request(app).get(`/api/photos/${'a'.repeat(32)}/secret`).expect(404);});
test('development uploads accept the real Vite origin with a backend Host header',async()=>{
 for(const origin of ['http://127.0.0.1:5173','http://localhost:5173']){
  const r=await request(app).post('/api/submissions').set('Host','127.0.0.1:3001').set('Origin',origin).field('consent','true').attach('photos',image,{filename:'proxy-test.png',contentType:'image/png'}).expect(201);
  assert.equal(r.body.status,'pending');
 }
 assert.equal((await request(app).get('/api/gallery')).body.photos.length,0);
 await request(app).post('/api/submissions').set('Host','127.0.0.1:3001').set('Origin','http://127.0.0.1:5174').send({}).expect(403);
 await request(app).post('/api/submissions').set('Origin','https://hostile.example').send({}).expect(403);
});
test('production rejects local development origins and permits only configured origin',async()=>{
 const p=createApp({dataDir:path.join(dataDir,'production'),production:true,publicOrigin:'https://gallery.example.org',allowPublicUploads:true});
 try{
  await request(p.app).post('/api/submissions').set('Origin','http://127.0.0.1:5173').send({}).expect(403);
  await request(p.app).post('/api/submissions').set('Origin','https://hostile.example').send({}).expect(403);
  await request(p.app).post('/api/submissions').set('Origin','https://gallery.example.org').field('consent','true').attach('photos',image,{filename:'test.png',contentType:'image/png'}).expect(201);
 }finally{p.db.close();}
});
test('two uploads survive a server restart, appear in review, then publish only after approval',async()=>{
 const persistentDir=path.join(dataDir,'persistence'),credentials=await testAdmin(persistentDir);let fixture=createApp({dataDir:persistentDir,variant:'combined'});
 const uploaded=await request(fixture.app).post('/api/submissions').set('Host','127.0.0.1:3001').set('Origin','http://127.0.0.1:5173').field('consent','true').attach('photos',image,{filename:'one.png',contentType:'image/png'}).attach('photos',image,{filename:'two.png',contentType:'image/png'}).expect(201);
 assert.equal(uploaded.body.count,2);const ids=fixture.db.prepare('SELECT id FROM photos').all().map(p=>p.id);fixture.db.close();
 fixture=createApp({dataDir:persistentDir,variant:'combined'});
 try{
  const reviewer=request.agent(fixture.app);
  await reviewer.post('/api/login').set('Host','127.0.0.1:3001').set('Origin','http://127.0.0.1:5173').send(credentials).expect(200);
  const queue=await reviewer.get('/api/admin/photos').expect(200);assert.match(queue.headers['cache-control'],/no-store/);assert.equal(queue.body.filter(p=>p.status==='pending').length,2);
  assert.deepEqual(queue.body.map(p=>p.id).sort(),ids.sort());assert.equal((await request(fixture.app).get('/api/gallery')).body.photos.length,0);
  for(const id of ids){await reviewer.get(`/api/photos/${id}/thumb`).expect(200);await request(fixture.app).get(`/api/photos/${id}/full`).expect(401);}
  await reviewer.patch('/api/admin/photos').send({ids,status:'approved'}).expect(200);
  assert.equal((await request(fixture.app).get('/api/gallery')).body.photos.length,2);
 }finally{fixture.db.close();}
});
