import {randomBytes} from 'node:crypto';
import {saveAdmin} from '../server/admin.mjs';
export async function testAdmin(dataDir){const credentials={username:'test-owner',password:randomBytes(24).toString('base64url')};await saveAdmin(dataDir,credentials.username,credentials.password);return credentials;}
