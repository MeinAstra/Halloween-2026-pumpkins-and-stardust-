import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import request from 'supertest';
import sharp from 'sharp';
import {createApp} from '../server/app.mjs';
import {testAdmin} from './helpers.mjs';
test('legacy photo records migrate without changing their identity, status or timestamps',async()=>{
 const dataDir=mkdtempSync(path.join(tmpdir(),'memory-migration-')),legacy=new DatabaseSync(path.join(dataDir,'gallery.sqlite'));
 const id='b'.repeat(32),created=1700000000000;
 legacy.exec('CREATE TABLE photos(id TEXT PRIMARY KEY,status TEXT NOT NULL,created INTEGER NOT NULL,demo INTEGER DEFAULT 0)');legacy.prepare('INSERT INTO photos VALUES(?,?,?,0)').run(id,'approved',created);legacy.close();
 const {app,db}=createApp({dataDir});
 try{const p=(await request(app).get('/api/gallery').expect(200)).body.photos[0];assert.equal(p.id,id);assert.equal(p.status,'approved');assert.equal(p.caption,'');assert.equal(p.uploadedAt,new Date(created).toISOString());assert.equal(db.prepare('SELECT COUNT(*) AS n FROM photos').get().n,1);}finally{db.close();rmSync(dataDir,{recursive:true,force:true});}
});
test('a real caption remains private until approval and persists across restart',async()=>{
 const dataDir=mkdtempSync(path.join(tmpdir(),'memory-caption-')),credentials=await testAdmin(dataDir);let fixture=createApp({dataDir});
 const image=await sharp({create:{width:80,height:60,channels:3,background:'#123456'}}).png().toBuffer(),caption='A night under the stars.';
 try{
  await request(fixture.app).post('/api/submissions').field('consent','true').field('caption','x'.repeat(281)).attach('photos',image,{filename:'test.png',contentType:'image/png'}).expect(400);
  await request(fixture.app).post('/api/submissions').field('consent','true').field('caption',caption).attach('photos',image,{filename:'test.png',contentType:'image/png'}).expect(201);
  assert.equal((await request(fixture.app).get('/api/gallery')).body.photos.length,0);
  fixture.db.close();fixture=createApp({dataDir});const reviewer=request.agent(fixture.app);
  await reviewer.post('/api/login').send(credentials).expect(200);const queue=(await reviewer.get('/api/admin/photos').expect(200)).body;assert.equal(queue[0].caption,caption);
  await reviewer.patch('/api/admin/photos').send({ids:[queue[0].id],status:'approved'}).expect(200);
  const photo=(await request(fixture.app).get('/api/gallery')).body.photos[0];assert.equal(photo.caption,caption);assert.ok(Number.isFinite(Date.parse(photo.uploadedAt)));assert.equal('filename' in photo,false);
 }finally{fixture.db.close();rmSync(dataDir,{recursive:true,force:true});}
});
