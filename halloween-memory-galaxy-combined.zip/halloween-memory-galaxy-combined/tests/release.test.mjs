import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,existsSync,readdirSync} from 'node:fs';
import path from 'node:path';
import {release} from '../server/config.mjs';
const root=process.cwd();
test('release config matches its declared package and contains no default administrator identity',()=>{
 const pkg=JSON.parse(readFileSync('package.json','utf8'));assert.equal(pkg.license,'PolyForm-Noncommercial-1.0.0');assert.ok(pkg.scripts['setup:admin']);
 const template=readFileSync('.env.example','utf8');for(const line of template.split('\n').filter(l=>/^[A-Z_]+=/.test(l)))assert.equal(line.split('=').slice(1).join('='),'');
 assert.equal(existsSync('data/admin.json')&&process.env.RELEASE_VERIFY==='true',false);
 if(process.env.RELEASE_VERIFY==='true'){
  assert.equal(pkg.name,release.name);
  for(const folder of [release.dataDir,'data','data-halloween','data-galaxy','screenshots'])assert.equal(existsSync(folder),false);
 }
});
test('no bundled source contains real credentials or external font imports',()=>{
 const style=readFileSync('src/style.css','utf8');assert.equal(style.includes('fonts.googleapis.com'),false);assert.equal(style.includes('@import url('),false);
 const read=(dir)=>readdirSync(dir,{withFileTypes:true}).flatMap(f=>f.isDirectory()?read(path.join(dir,f.name)):[path.join(dir,f.name)]);
 for(const f of [...read('src'),...read('server')]){
  const text=readFileSync(f,'utf8');assert.equal(/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/.test(text),false,f);
  assert.equal(/(?:gh[pousr]_[A-Za-z0-9]{30,}|sk-proj-[A-Za-z0-9_-]{30,}|AKIA[0-9A-Z]{16})/.test(text),false,f);
 }
 assert.ok(existsSync(path.join(root,'LICENSE')));assert.ok(existsSync(path.join(root,'NOTICE')));
});
