import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,readFileSync,existsSync,writeFileSync,statSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {randomBytes,createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import request from 'supertest';
import sharp from 'sharp';
import {createApp} from '../server/app.mjs';
import {saveAdmin,loadAdmin,validateAdmin} from '../server/admin.mjs';
import {migrateLegacy,revokeSessions} from '../server/setup-admin.mjs';
import {release,variants,allowedPage} from '../server/config.mjs';
import {testAdmin} from './helpers.mjs';
const temporary=()=>mkdtempSync(path.join(tmpdir(),'gallery-security-'));
const password=()=>randomBytes(24).toString('base64url');
test('first run has no public/default admin account or registration endpoint',async()=>{
 const dataDir=temporary(),{app,db}=createApp({dataDir});try{
  assert.equal(loadAdmin(dataDir),null);assert.equal(existsSync(path.join(dataDir,'development-credentials.json')),false);
  await request(app).post('/api/login').send({username:'admin',password:password()}).expect(503);
  for(const route of ['/api/setup','/api/register-admin','/api/admin/credentials'])await request(app).post(route).send({}).expect(404);
  for(const route of ['/data/admin.json','/data/development-credentials.json','/.env','/setup','/register-admin','/api/admin.json'])await request(app).get(route).expect(404);
 }finally{db.close();rmSync(dataDir,{recursive:true,force:true});}
});
test('custom admin hash persists, wrong credentials are generic, reset revokes sessions live and after restart',async()=>{
 const dataDir=temporary(),chosen=password();await saveAdmin(dataDir,'my-own-owner',chosen);let f=createApp({dataDir});
 try{
  const stored=readFileSync(path.join(dataDir,'admin.json'),'utf8');assert.equal(stored.includes(chosen),false);assert.equal('password' in JSON.parse(stored),false);assert.equal(statSync(path.join(dataDir,'admin.json')).mode&0o777,0o600);
  const wrongUser=await request(f.app).post('/api/login').send({username:'unknown',password:chosen}).expect(401),wrongPass=await request(f.app).post('/api/login').send({username:'my-own-owner',password:password()}).expect(401);assert.deepEqual(wrongUser.body,wrongPass.body);
  f.db.close();f=createApp({dataDir});const agent=request.agent(f.app),r=await agent.post('/api/login').send({username:'my-own-owner',password:chosen}).expect(200);await agent.get('/api/session').expect(200);
  const token=r.headers['set-cookie'][0].split(';')[0].split('=')[1];assert.equal(f.db.prepare('SELECT token FROM sessions').get().token,createHash('sha256').update(token).digest('hex'));
  const replacement=password();await saveAdmin(dataDir,'new-owner',replacement,{replace:true});await agent.get('/api/session').expect(401);revokeSessions(dataDir);assert.equal(f.db.prepare('SELECT COUNT(*) AS n FROM sessions').get().n,0);
  f.db.close();f=createApp({dataDir});await request(f.app).post('/api/login').send({username:'new-owner',password:replacement}).expect(200);
 }finally{f.db.close();rmSync(dataDir,{recursive:true,force:true});}
});
test('legacy migration preserves login, removes plaintext only after a hash is saved, and never replaces an existing admin',async()=>{
 const dataDir=temporary(),credentials={username:'admin',password:password()},file=path.join(dataDir,'development-credentials.json');writeFileSync(file,JSON.stringify(credentials),{mode:0o600});
 try{await migrateLegacy(dataDir);assert.equal(existsSync(file),false);const {app,db}=createApp({dataDir});try{await request(app).post('/api/login').send(credentials).expect(200);}finally{db.close();}
 writeFileSync(file,JSON.stringify(credentials),{mode:0o600});await assert.rejects(migrateLegacy(dataDir));assert.equal(existsSync(file),true);
 }finally{rmSync(dataDir,{recursive:true,force:true});}
});
test('strength validation rejects weak setup and CLI refuses noninteractive password arguments',()=>{
 assert.throws(()=>validateAdmin('ab','short'));assert.throws(()=>validateAdmin('owner','a'.repeat(30)));assert.throws(()=>validateAdmin('../owner',password()));
 const r=spawnSync(process.execPath,['server/setup-admin.mjs','--password=NO_REAL_PASSWORD'],{encoding:'utf8'});assert.notEqual(r.status,0);assert.equal(r.stdout.includes('NO_REAL_PASSWORD'),false);assert.equal(r.stderr.includes('NO_REAL_PASSWORD'),false);
});
test('three variants have independent empty stores, routes, default copy, cookie names and origins',async()=>{
 const root=temporary(),fixtures=[];try{
  const names=new Set(),dirs=new Set(),ports=new Set();
  for(const [variant,c]of Object.entries(variants)){
   dirs.add(c.dataDir);ports.add(c.apiPort);ports.add(c.devPort);assert.ok(allowedPage('/',variant));assert.equal(allowedPage('/galaxy',variant),variant==='combined');assert.equal(allowedPage('/halloween',variant),variant==='combined');
   const dataDir=path.join(root,c.dataDir),credentials=await testAdmin(dataDir),f=createApp({dataDir,variant});fixtures.push(f);const gallery=(await request(f.app).get('/api/gallery')).body;assert.equal(gallery.photos.length,0);
   if(variant==='galaxy'){assert.equal(gallery.config.school,'Our memories');assert.equal(gallery.config.title,'Memory Galaxy');}
   const login=await request(f.app).post('/api/login').send(credentials).expect(200),cookie=login.headers['set-cookie'][0].split(';')[0];names.add(cookie.split('=')[0]);
   for(const other of fixtures.slice(0,-1))await request(other.app).get('/api/session').set('Cookie',cookie).expect(401);
   await request(f.app).post('/api/submissions').set('Host',`127.0.0.1:${c.apiPort}`).set('Origin',`http://127.0.0.1:${c.devPort}`).send({}).expect(400);
   const wrong=c.devPort===5173?5174:5173;await request(f.app).post('/api/submissions').set('Host',`127.0.0.1:${c.apiPort}`).set('Origin',`http://127.0.0.1:${wrong}`).send({}).expect(403);
  }
  assert.equal(names.size,3);assert.equal(dirs.size,3);assert.equal(ports.size,6);assert.ok(variants[release.variant]);
 }finally{fixtures.forEach(f=>f.db.close());rmSync(root,{recursive:true,force:true});}
});
test('production requires exact HTTPS origin, secure cookies, controlled uploads and strict fetch metadata',async()=>{
 const dataDir=temporary(),credentials=await testAdmin(dataDir);assert.throws(()=>createApp({dataDir,production:true}));
 const {app,db}=createApp({dataDir,production:true,publicOrigin:'https://gallery.example.org'});try{
  const r=await request(app).post('/api/login').set('Origin','https://gallery.example.org').send(credentials).expect(200);assert.match(r.headers['set-cookie'][0],/Secure/);assert.match(r.headers['content-security-policy'],/default-src 'self'/);
  await request(app).post('/api/submissions').set('Origin','https://gallery.example.org').send({}).expect(403);
  await request(app).post('/api/login').set('Sec-Fetch-Site','cross-site').send(credentials).expect(403);
  assert.equal((await request(app).get('/api/gallery')).body.uploadsEnabled,false);
 }finally{db.close();rmSync(dataDir,{recursive:true,force:true});}
});
test('EXIF is stripped, SVG is rejected before native decoding, excessive dimensions and hidden/rejected files stay private',async()=>{
 const dataDir=temporary(),credentials=await testAdmin(dataDir),{app,db,objects}=createApp({dataDir});try{
  const image=await sharp({create:{width:30,height:30,channels:3,background:'#123456'}}).jpeg().withExif({IFD0:{Artist:'TEST_METADATA_ONLY'},IFD2:{DateTimeOriginal:'2020:01:01 00:00:00'}}).toBuffer();
  await request(app).post('/api/submissions').field('consent','true').attach('photos',image,{filename:'private-person.jpg',contentType:'image/jpeg'}).expect(201);
  const id=db.prepare('SELECT id FROM photos').get().id;
  const meta=await sharp(readFileSync(path.join(objects,`${id}-full.webp`))).metadata();assert.equal(meta.exif,undefined);assert.equal(meta.iptc,undefined);assert.equal(meta.xmp,undefined);
  await request(app).post('/api/submissions').field('consent','true').attach('photos',Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"/>'),{filename:'bad.png',contentType:'image/png'}).expect(400);
  const wide=await sharp({create:{width:16001,height:1,channels:3,background:'#000000'}}).png().toBuffer();await request(app).post('/api/submissions').field('consent','true').attach('photos',wide,{filename:'wide.png',contentType:'image/png'}).expect(400);
  for(const status of ['pending','hidden','rejected']){db.prepare('UPDATE photos SET status=? WHERE id=?').run(status,id);for(const v of ['full','thumb'])await request(app).get(`/api/photos/${id}/${v}`).expect(401);}
  const agent=request.agent(app);await agent.post('/api/login').send(credentials).expect(200);await agent.get(`/api/photos/${id}/full`).expect(200);
  await request(app).get('/api/photos/%2e%2e%2fadmin.json/full').expect(404);
 }finally{db.close();rmSync(dataDir,{recursive:true,force:true});}
});
test('aggregate upload cap is enforced while streaming and public storage paths are rejected',async()=>{
 const dataDir=temporary(),{app,db}=createApp({dataDir});try{
  const file=Buffer.alloc(9*1024*1024);let r=request(app).post('/api/submissions').field('consent','true');for(let i=0;i<3;i++)r=r.attach('photos',file,{filename:'test.png',contentType:'image/png'});await r.expect(413);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM photos').get().n,0);
  assert.throws(()=>createApp({dataDir:'public/unsafe-storage'}));await assert.rejects(saveAdmin('public/unsafe-storage','owner',password()));assert.equal(existsSync('public/unsafe-storage'),false);
 }finally{db.close();rmSync(dataDir,{recursive:true,force:true});}
});

test('storage setup refuses an unrelated populated directory without changing it',async()=>{
 const dataDir=temporary(),file=path.join(dataDir,'unrelated.txt');writeFileSync(file,'keep me');const mode=statSync(dataDir).mode;
 try{assert.throws(()=>createApp({dataDir}));await assert.rejects(saveAdmin(dataDir,'owner',password()));assert.equal(readFileSync(file,'utf8'),'keep me');assert.equal(statSync(dataDir).mode,mode);}finally{rmSync(dataDir,{recursive:true,force:true});}
});
test('expired sessions are rejected server-side',async()=>{
 const dataDir=temporary(),credentials=await testAdmin(dataDir),{app,db}=createApp({dataDir});try{
  const agent=request.agent(app);await agent.post('/api/login').send(credentials).expect(200);db.prepare('UPDATE sessions SET expires=?').run(Date.now()-1);await agent.get('/api/session').expect(401);await agent.get('/api/admin/photos').expect(401);
 }finally{db.close();rmSync(dataDir,{recursive:true,force:true});}
});
test('built edition serves only its own page routes and appropriate title',{skip:!existsSync('dist/index.html')},async()=>{
 const dataDir=temporary(),{app,db}=createApp({dataDir});try{
  const root=await request(app).get('/').expect(200);assert.ok(root.text.includes(`<title>${release.title.replaceAll('&','&amp;')}</title>`));
  for(const route of ['/halloween','/galaxy'])await request(app).get(route).expect(release.variant==='combined'?200:404);
  for(const route of ['/admin','/submit'])await request(app).get(route).expect(200);
 }finally{db.close();rmSync(dataDir,{recursive:true,force:true});}
});
