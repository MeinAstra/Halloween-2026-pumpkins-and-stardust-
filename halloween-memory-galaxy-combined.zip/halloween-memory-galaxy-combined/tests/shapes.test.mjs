import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import * as T from 'three';
import {pumpkinPaths,pathSamples,memoryAnchor} from '../src/shapes.ts';
import {maskContours,createPorcelainMask,maskDepth,sampleMask} from '../src/porcelainMask.ts';
import {gardenPaths,createGarden} from '../src/celestialGarden.ts';

// Read actual mesh data from the vendored GLB without image decoding or a browser.
function pumpkin(){
 const file=readFileSync(new URL('../public/models/pumpkin.glb',import.meta.url));
 assert.equal(file.readUInt32LE(8),file.length,'GLB must be complete');
 const jsonSize=file.readUInt32LE(12),gltf=JSON.parse(file.toString('utf8',20,20+jsonSize)),binary=28+jsonSize;
 function accessor(index){const a=gltf.accessors[index],view=gltf.bufferViews[a.bufferView],start=binary+(view.byteOffset||0)+(a.byteOffset||0),arity=a.type==='VEC3'?3:1,ctor={5126:Float32Array,5123:Uint16Array,5125:Uint32Array}[a.componentType];const bytes=file.subarray(start,start+a.count*arity*ctor.BYTES_PER_ELEMENT);return new ctor(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));}
 const primitive=gltf.meshes[0].primitives[0],geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.BufferAttribute(accessor(primitive.attributes.POSITION),3));geometry.setIndex(new T.BufferAttribute(accessor(primitive.indices),1));
 const mesh=new T.Mesh(geometry,new T.MeshBasicMaterial());mesh.position.fromArray(gltf.nodes.find(n=>n.mesh===0).translation);const model=new T.Group();model.add(mesh);
 const box=new T.Box3().setFromObject(model),size=box.getSize(new T.Vector3()),center=box.getCenter(new T.Vector3()),scale=4.7/Math.max(size.x,size.z);center.y=box.min.y+size.y*.43;model.position.copy(center.multiplyScalar(-scale));model.scale.setScalar(scale);model.updateMatrixWorld(true);return model;
}
test('imported pumpkin produces at least eight recessed groove splines',()=>{const model=pumpkin(),paths=pumpkinPaths(model);assert.ok(paths.length>=8&&paths.length<=12);for(const path of paths){assert.ok(path.curve.points.length>=60);assert.ok(path.curve.getLength()>2);}});
test('groove samples stay above the actual GLB surface, including spline midpoints',()=>{
 const model=pumpkin(),paths=pumpkinPaths(model),ray=new T.Raycaster(),box=new T.Box3().setFromObject(model),center=box.getCenter(new T.Vector3());
 for(const path of paths)for(const p of path.curve.getSpacedPoints(100)){
  const direction=new T.Vector3(p.x-center.x,0,p.z-center.z).normalize(),origin=new T.Vector3(center.x,p.y,center.z).addScaledVector(direction,8);ray.set(origin,direction.clone().negate());const hit=ray.intersectObject(model,true)[0];assert.ok(hit);const clearance=p.clone().sub(hit.point).dot(direction);assert.ok(clearance>.035&&clearance<.1,`surface clearance ${clearance}`);
 }
});
test('sparse collections preserve stable unique photo anchors independently of photo count',()=>{for(const paths of [maskContours(),gardenPaths(),pumpkinPaths(pumpkin())]){assert.ok(paths.length>=3);for(const count of [1,3,10,20,240]){const ids=Array.from({length:count},(_,i)=>`photo-${i}`),forward=ids.map(id=>memoryAnchor(id,paths).toArray()),reverse=ids.toReversed().map(id=>memoryAnchor(id,paths).toArray()).toReversed();assert.deepEqual(forward,reverse);assert.equal(new Set(forward.map(JSON.stringify)).size,count);assert.ok(forward.flat().every(Number.isFinite));}}});
test('porcelain shell has an actual through-eye, deep nose and irregular cropped boundary',()=>{
 const geometry=createPorcelainMask(),mesh=new T.Mesh(geometry,new T.MeshBasicMaterial({side:T.DoubleSide})),ray=new T.Raycaster();
 ray.set(new T.Vector3(-.75,-.15,6),new T.Vector3(0,0,-1));assert.equal(ray.intersectObject(mesh).length,0,'eye must contain no geometry');
 ray.set(new T.Vector3(-.75,.55,6),new T.Vector3(0,0,-1));const brow=ray.intersectObject(mesh);assert.ok(brow.length>=2,'shell has front and rear surfaces');assert.ok(brow[1].distance-brow[0].distance>.05);
 const projection=maskDepth(.35,-.53)-maskDepth(-.9,-.53);assert.ok(projection>.65&&projection<.95,'nose projects naturally without a beak-like profile');
 assert.ok(geometry.boundingBox.min.y>-1.3,'no mouth or chin fragment');assert.ok(geometry.boundingBox.max.y>2);geometry.dispose();
});
test('mask particles sample the shell and concentrate on its distinguishing contours',()=>{const g=createPorcelainMask(),p=sampleMask(g,20000);assert.equal(p.positions.length,60000);assert.ok(p.positions.every(Number.isFinite));assert.ok(p.edge.reduce((a,b)=>a+b,0)>=2500);const tip=Math.max(...p.positions.filter((_,i)=>i%3===2));assert.ok(tip>.8&&tip<1.1);g.dispose();});
test('celestial garden is deterministic and volumetric with varied star sizes and colors',()=>{const a=createGarden(12000),b=createGarden(12000);assert.deepEqual(a.positions,b.positions);const z=Array.from(a.positions).filter((_,i)=>i%3===2),mean=z.reduce((a,b)=>a+b,0)/z.length,std=Math.sqrt(z.reduce((a,b)=>a+(b-mean)**2,0)/z.length);assert.ok(std>.8);assert.ok(Math.max(...a.sizes)>.1);assert.ok(Math.min(...a.sizes)<.02);assert.ok(new Set(Array.from(a.colors).map(v=>v.toFixed(2))).size>30);});
test('decorative dots use approximately equal arc-length spacing',()=>{for(const path of [...maskContours(),...gardenPaths()]){const p=path.curve.getSpacedPoints(Math.ceil(path.curve.getLength()/.075)),d=p.slice(1).map((v,i)=>v.distanceTo(p[i])),mean=d.reduce((a,b)=>a+b,0)/d.length;assert.ok(Math.min(...d)>mean*.76);assert.ok(Math.max(...d)<mean*1.15);}});
