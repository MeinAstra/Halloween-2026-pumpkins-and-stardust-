import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import {readFileSync} from 'node:fs';
import release from './app.config.json';
const notice=readFileSync('NOTICE','utf8').split('\n').filter(line=>line.startsWith('Required Notice:')).join('\n');
export default defineConfig({plugins:[react()],esbuild:{legalComments:'inline'},build:{rollupOptions:{output:{banner:`/*! Original application code: PolyForm Noncommercial 1.0.0
https://polyformproject.org/licenses/noncommercial/1.0.0
${notice}
Third-party components retain their own licenses; see /NOTICE.txt and THIRD_PARTY.md. */`}}},server:{port:release.devPort,strictPort:true,proxy:{'/api':`http://127.0.0.1:${release.apiPort}`}}});
